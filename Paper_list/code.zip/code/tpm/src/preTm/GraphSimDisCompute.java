package preTm;
import java.util.*;
import java.io.*;
import java.math.*;
import beans.*;


import preTm.*;
public class GraphSimDisCompute {
	//0 is the host 1 is the hostess...
 public static double dis_doubles(double[] array_0,double[] array_1){
	 double target=0.0;
	 for(int i=0;i<array_0.length;i++){
	   double sum=array_0[i]*(Math.log(array_0[i]/array_1[i]));
	   target+=sum;
	 }
	 return target;
 }
 
   
 public static double dis_doubles_sim(double[] array_0,double[] array_1){
	 double x=sim_doubles(array_0,array_1);
	 x=1-x;
	 return x;
 }
 
 
 public static double sim_doubles(double[] array_0,double[] array_1){
	 
	 double target=0.0;
	 double x=0.0;
	 double y=0.0;
	 for(int i=0;i<array_0.length;i++){
		 x+=(array_0[i]*array_0[i]);
	 }
	 x=Math.sqrt(x);
	 
	 for(int i=0;i<array_1.length;i++){
		 y+=(array_1[i]*array_1[i]);
	 }
	 y=Math.sqrt(y);
	 
	 for(int i=0;i<array_0.length;i++){
		 target+=array_0[i]*array_1[i];
	 }
	 
	 target=target/(x*y);
	 return target;
 }
 
 public static double cos_words(ArrayList<Word> word_0,ArrayList<Word> word_1){
	 //int count=0;
	 double product=0.0;
	 double x=0.0;
	 double y=0.0;
	 for(int i=0;i<word_0.size();i++){
		 x+=(word_0.get(i).tfidf*word_0.get(i).tfidf);
		 for(int j=0;j<word_1.size();j++){
			 y+=word_1.get(j).tfidf*word_1.get(j).tfidf;
			 product+=(word_0.get(i).tfidf*word_1.get(j).tfidf);
		 }
	 }
	 
	 x=Math.sqrt(x);
	 y=Math.sqrt(y);
	 
	 product=(product/x*y);
	 
	 //double x=0.0;
	 //for()
	 
	 
	 return product;
 }
 
 
 public static double[] getMeanValue(double[] array){
	 double[] target=array;
	 
	 double sum=0.0;
	 for(int i=0;i<array.length;i++){
		 sum+=array[i];
	 }
	 for(int i=0;i<array.length;i++){
		 target[i]=array[i]/sum;
	 }
	 return target;
 }
 
 
 
}
