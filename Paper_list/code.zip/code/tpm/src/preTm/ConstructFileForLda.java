package preTm;
import java.util.*;
import java.math.*;
import beans.*;
import usageTool.*;
import java.io.*;

public class ConstructFileForLda {
    public static String INPATH="E:\\WORK\\MyPaper\\ExperimentData\\PRocess";
    public static String OUTPATH="E:\\WORK\\MyPaper\\ExperimentData\\NEW_PRO";
    
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		//BufferedReader reader;
		PrintWriter writer;
		
		ArrayList<ArrayList<Integer>> pos_clus=new ArrayList<ArrayList<Integer>>();
		ArrayList<Integer> stu_clu=new ArrayList<Integer>();
		
		
		
		try{
			File filePath=new File(INPATH);
			if(filePath.isDirectory()){
				String[] fileList=filePath.list();
				
				for(int i=0;i<fileList.length;i++){
					String inputPath=INPATH+"\\"+fileList[i];
					System.out.println(inputPath);
					
					File outputPath=new File(OUTPATH+"\\"+fileList[i].substring(0,fileList[i].indexOf(".")));
					
					writer=new PrintWriter(outputPath.getPath()+"\\globe_forLda.txt");
					
					ConstructBeans constructBeans=new ConstructBeans();
			        constructBeans.constructWord(inputPath);
					constructBeans.constructSens(inputPath);
					constructBeans.addCommunSenWorPos();
					
					writer.println(constructBeans.POSTS.size());
					//System.out.println(constructBeans.POSTS.size());
					for(int j=0;j<constructBeans.POSTS.size();j++){
						Post post=constructBeans.POSTS.get(j);
						ArrayList<Word> words=post.pos_wors;
						
						for(int ii=0;ii<words.size();ii++){
							if(ii==0){
								//System.out.println(words.get(ii).word);
								writer.print(words.get(ii).word);
							}
							else{
								//System.out.println(words.get(ii).word);
								writer.print(" "+words.get(ii).word);	
							}							
						}
						writer.println();
						
					}
					
					writer.flush();
					writer.close();
					
					// begin the hi-clu data for lda
					
					BufferedReader reader=new BufferedReader(new FileReader(outputPath.getPath()+"\\hi_clu.txt"));
					
					String line="";
					int index=0;
					while((line=reader.readLine())!=null){
						String[] numsOfOneClus=line.split(" ");
						
						System.out.println("numsofoneclus  ->"+(numsOfOneClus.length));
						
						writer=new PrintWriter(outputPath.getPath()+"\\"+index+".txt");
						
						writer.println(numsOfOneClus.length);
						
						
						for(int j=0;j<numsOfOneClus.length;j++){
							
							int x=Integer.parseInt(numsOfOneClus[j]); //index num
							
							Post post=null;
							
							
							for(int l=0;l<constructBeans.POSTS.size();l++){
								if(constructBeans.POSTS.get(l).number==x){
									post=constructBeans.POSTS.get(l);
									
									break;
								}
							}
								
							
							if(post!=null){
							
							System.out.println(post.number);
							
							ArrayList<Word> words=post.pos_wors;
							for(int ii=0;ii<words.size();ii++){
								if(ii==0){
									//System.out.println(words.get(ii).word);
									writer.print(words.get(ii).word);
								}
								else{
									//System.out.println(words.get(ii).word);
									writer.print(" "+words.get(ii).word);	
								}							
							}
							writer.println();
							
						  }else{
							  System.out.println("FF");
						  }
							
							
						}
						
						writer.flush();
						writer.close();
						
						
						System.out.println(index);
				
						index++;
					}
					
					reader.close();
					
					writer=new PrintWriter(outputPath.getPath()+"\\sta.txt");
					
					writer.println((index-1));
					
					writer.flush();
					writer.close();
					
				}
				
			}else{
				System.out.println("filePath is not a directory");
			}
			
			
			
		}catch(Exception e){
			System.out.println(e.getLocalizedMessage());
		}
		
		
		
		
		// TODO Auto-generated method stub

	}

}
