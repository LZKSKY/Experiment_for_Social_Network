package preTm;

import java.util.*;
import java.io.*;
import java.math.*;

public class SegThread {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
         
	}

}
