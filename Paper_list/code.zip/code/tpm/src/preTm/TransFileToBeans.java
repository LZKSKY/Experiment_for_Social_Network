package preTm;

import java.util.*;
import java.io.*;
import java.math.*;
import beans.*;
  
public class TransFileToBeans {
	public static String DOCIN = "";
	public static String FILEOUT = "";
	public final static String C_SENTENCE = ".!?";
	public static String C_EXCEPT_1 = "\"";
	public static String C_EXCEPT_2 = "()";
	
    //
	public static ArrayList<String> splitSens(String inputPath) {
		BufferedReader reader;
		ArrayList<String> list_sen = new ArrayList<String>();
		try {
			reader = new BufferedReader(new FileReader(inputPath));
			StringBuffer context = new StringBuffer();
			String line = reader.readLine();
			while (line != null) {
				context.append(line);
				line = reader.readLine();
			}
			String sentences = context.toString();
			int begin = 0;
			int end = 0;
			boolean findBraket = false;
			for (int i = 0; i < sentences.length(); i++) {
				boolean findSplit = false;
				
				for(int j=0;j<3;j++){
					if(sentences.charAt(i)==C_SENTENCE.charAt(j))
						findSplit=true;
				}
				//System.out.println(sentences.length());
				if(findSplit==true){
				 if(i<sentences.length()-1){
					 //System.out.println(i);
					 if(!(sentences.substring(i+1,i+2).equals(" ")))
						 findSplit=false;
				 }	
				}
				
				if(findSplit==true){
					findSplit=false;
					end++;
					list_sen.add(sentences.substring(begin, end));
					begin=end;
				}else{
					end++;
				}
			}
			// for(int i=0;i<list_sen.size();i++){
			// System.out.println(list_sen.get(i));
			// }

		} catch (Exception e) {
			System.out.println(e.toString());
		}
		return list_sen;
	}

	public static ArrayList<String> splitSensFromDoc(String sentences) {
		
		ArrayList<String> list_sen = new ArrayList<String>(0);
		
		int begin = 0;
		int end = 0;
		//boolean findBraket = false;
		
		for (int i = 0; i < sentences.length(); i++) {
			boolean findSplit = false;
			boolean t_0=false;
			for(int j=0;j<3;j++){
				if(sentences.charAt(i)==C_SENTENCE.charAt(j))
					findSplit=true;
				    //t_0=true;
			}
			//System.out.println(sentences.length());
			if(findSplit==true){
			 if(!((sentences.charAt(i-1)>='a')&&(sentences.charAt(i-1)<='z')))
				 findSplit=false;
			}
			
			if(findSplit==true){
				 if(i<(sentences.length()-1)){
					 //System.out.println(i);
					 if(!(sentences.substring(i+1,i+2).equals(" ")))
						 findSplit=false;
				 }	
				}
			if((i<(sentences.length()-1))&&(i>1)&&(findSplit==false)){
				//System.out.println(i);
			if((((sentences.charAt(i-1)>='a')&&(sentences.charAt(i-1)<='z'))||(C_SENTENCE.contains(sentences.substring(i-1,i))))&&(C_SENTENCE.contains(sentences.substring(i,i+1)))&&((sentences.charAt(i+1)>='A')&&(sentences.charAt(i+1)<='Z')))
				{findSplit=true;
				 //t_0=false;
				}
			}
			if(i==sentences.length()-1){
				findSplit=true;
			}
			if(findSplit==true){
				findSplit=false;
				//t_0=false;
				end++;
				list_sen.add(sentences.substring(begin, end));
				begin=end;
			}else{
				end++;
			}
		}
		
		
		return list_sen;
	}
	
	public static ArrayList<ArrayList<String>> splitSensToWords(ArrayList<String> sens){
		
		ArrayList<ArrayList<String>> sens_wors=new ArrayList<ArrayList<String>>(0);
		SplitStopWords splitStopWords=new SplitStopWords();
		for(int i=0;i<sens.size();i++){
			ArrayList<String> words=splitStopWords.tokenize(sens.get(i), true, true);
			sens_wors.add(words);
		}
		
		return sens_wors;
	}
	
	public static ArrayList<ArrayList<String>> splitSensToWords_sec(ArrayList<String> sens){
		ArrayList<ArrayList<String>> sens_wors=new ArrayList<ArrayList<String>>(0);
		SplitStopWords splitStopWords=new SplitStopWords();
		for(int i=0;i<sens.size();i++){
			ArrayList<String> words=splitStopWords.tokenize(sens.get(i), false, true);
			sens_wors.add(words);
		}
		
		return sens_wors;
	}
	
	
	public static ArrayList<String> splitSensToWords(String sens){
		SplitStopWords splitStopWords=new SplitStopWords();
		ArrayList<String> words=splitStopWords.tokenize(sens, true, true);
		return words;
	}
	
	public static ArrayList<String> splitSensToWords_sec(String sens){
		SplitStopWords splitStopWords=new SplitStopWords();
		ArrayList<String> words=splitStopWords.tokenize(sens, false, true);
		return words;
	}
	
	public static void main(String[] args){
		System.out.println(".xx");
		
		/*
		ArrayList<String> xx=new ArrayList<String>(0);
		
		String t1="uu";
		String t2="ud";
		String t3="uo";
		xx.add(t1);
		xx.add(t2);
		xx.add(t3);
		
		xx.remove("uu");
		System.out.println(xx.indexOf("uo"));
		*/
		/*
		Word word=new Word();
		Sentence sen=new Sentence();
		word.word="f";
		sen.sen_words.add(word);
		word.wor_sens.add(sen);
		word.word="jkdsjak";
		
		word=new Word();
		
		
		System.out.println(sen.getSen_words().get(0).word);
		
		word=sen.sen_words.get(0);
		word.word="dfffff";
		word=new Word();
		*/
		//sen.sen_words.remove(0);
		//sen.sen_words.add(word);
		//System.out.println(sen.getSen_words().get(0).word);
		
		//ArrayList<String> temp_out=splitSensFromDoc("Have you tried redownloading the GEAR drivers from feed://www.gearsoftware.com/rss/GEAR-drivers-feed.php ?Sometimes reinstalling them fixes the problem.I also found this wiki post that might help - http://www.gearsoftware.com/wiki/index.php?title=CD/DVD_drives_disappearing_due_to_incorrect_registry_entryMessage was edited by: Steeley");
		//ArrayList<ArrayList<String>> temp_ott=splitSensToWords(temp_out);
		//for(int i=0;i<temp_out.size();i++){
		//	System.out.println(temp_out.get(i));
		//}
	}
	
	
}
