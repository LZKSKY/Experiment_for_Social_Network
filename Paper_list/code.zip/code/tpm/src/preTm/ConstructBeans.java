package preTm;

import java.util.*;
import java.io.*;
import java.math.*;
import beans.*;
import usageTool.*;
import java.util.Timer;
public class ConstructBeans {
	public ArrayList<Word> WORDS;
	public ArrayList<Sentence> SENS;
	public ArrayList<Post> POSTS;
    public double[][] DIS_posts;
	public ConstructBeans() {
		WORDS = new ArrayList<Word>(0);
		SENS = new ArrayList<Sentence>(0);
		POSTS = new ArrayList<Post>(0);
	}
    
	//���ǲ���Ӧ�������������������·��ѡ���㷨��ʵ�֣�
	
	public void reconstructReplyRelation(){
		//reconstruct the relations among posts...
		for(int i=0;i<POSTS.size();i++){
		    Post post = POSTS.get(i);
		    ArrayList<Post> post_men=post.mention;
		    
		    int maxNum=-1;
		    
		    double max=0.0;
		    
		    for(int j=0;j<post_men.size();j++){
		      double sim_topic=	GraphSimDisCompute.sim_doubles(post.affi_topic, post_men.get(j).affi_topic);
		      double sim_words= GraphSimDisCompute.cos_words(post.pos_wors, post_men.get(j).pos_wors);
		      double tar=1.2*sim_topic+sim_words;
		      if(tar>max){
		    	  maxNum=post_men.get(j).number;
		    	  max=tar;
		      }
		    }
		    
		   // System.out.println(maxNum+"----"+max);
		    //Post post_1=new Post();
		    for(int j=0;j<post.mention.size();j++){
		    	if(post.mention.get(j).number!=maxNum){
		    		//delete....
		    		for(int p=0;p<POSTS.size();p++){
		    			if(POSTS.get(p).number==post.mention.get(j).number){
		    				//System.out.println("fuck");
		    				//if(POSTS.get(p).pos_posts.contains(post)){
		    					//System.out.println("fuck");
		    					POSTS.get(p).pos_posts.remove(post);
		    				//}
		    			}
		    		}
		    		
		    	}
		    }
		    
		    ArrayList<Post> men_0=new ArrayList<Post>(0);
		    for(int j=0;j<POSTS.size();j++){
		    	if(POSTS.get(j).number==maxNum){
		    		men_0.add(POSTS.get(j));
		    	}
		    }
		    
		    
		    post.mention=men_0;
		    
		    POSTS.remove(i);
		    POSTS.add(i,post);
		    		    
		}
		
		/****************************************/
		
		
		System.out.println("*********%%%%%*******************POSTS************************************************");
		for(int i=0;i<POSTS.size();i++){
			System.out.println("****************************************************************************");
			System.out.print(POSTS.get(i).number+"    ->number    |");
			System.out.print(POSTS.get(i).topic+"     ->topic     |");
			System.out.print(POSTS.get(i).author+"    ->author    |");
			System.out.print(POSTS.get(i).time+"      ->time    |");
			//System.out.print(constructBeans.POSTS.get(i).pos_sens.size+" ->sens size");
			System.out.println("&&&&&&&&&&&SENS&&&&&&&&&&&&&");
			for(int j=0;j<POSTS.get(i).pos_sens.size();j++){
				System.out.println(POSTS.get(i).pos_sens.get(j).number+"   ->POST SEN NUM");
			}
			System.out.println("&&&&&&&&&&&POSTS&&&&&&&&&&&&&");
			for(int j=0;j<POSTS.get(i).pos_wors.size();j++){
				System.out.println(POSTS.get(i).pos_wors.get(j).word+"   ->POST word word");
			}
			System.out.println("&&&&&&&&&&&&MENTION&&&&&&&&&&&&");
			for(int j=0;j<POSTS.get(i).mention.size();j++){
				System.out.println(POSTS.get(i).mention.get(j).number+"   -> post mention");
			}
			System.out.println("&&&&&&&&&&&&ATUHOR&&&&&&&&&&&&");
			for(int j=0;j<POSTS.get(i).pos_author.size();j++){
				System.out.println(POSTS.get(i).pos_author.get(j).number+"   -> pos_author");
			}
			System.out.println("&&&&&&&&&&&&POSTSPOSTS&&&&&&&&&&&&");
			for(int j=0;j<POSTS.get(i).pos_posts.size();j++){
				System.out.println(POSTS.get(i).pos_posts.get(j).number+"   -> post post");
			}
			System.out.println("****************************END*******************************************");
		}
		
		
		/***************************************/
		
	}
	
	public void reconstructMentions(){
		for(int i=0;i<POSTS.size();i++){
			Post post=POSTS.get(i);
			
			ArrayList<Post> mens=new ArrayList<Post>(0);
			
			for(int j=0;j<post.mention.size();j++){
				mens.add(post.mention.get(j));
			}
			for(int j=0;j<post.pos_posts.size();j++){
				mens.add(post.pos_posts.get(j));
			}
			
			post.mention=mens;
			
			POSTS.remove(i);
			POSTS.add(i,post);
		}
		
		
		
		System.out.println("*********%%%%%*******************POSTS************************************************");
		for(int i=0;i<POSTS.size();i++){
			System.out.println("****************************************************************************");
			System.out.print(POSTS.get(i).number+"    ->number    |");
			System.out.print(POSTS.get(i).topic+"     ->topic     |");
			System.out.print(POSTS.get(i).author+"    ->author    |");
			System.out.print(POSTS.get(i).time+"      ->time    |");
			//System.out.print(constructBeans.POSTS.get(i).pos_sens.size+" ->sens size");
			System.out.println("&&&&&&&&&&&SENS&&&&&&&&&&&&&");
			for(int j=0;j<POSTS.get(i).pos_sens.size();j++){
				System.out.println(POSTS.get(i).pos_sens.get(j).number+"   ->POST SEN NUM");
			}
			System.out.println("&&&&&&&&&&&POSTS&&&&&&&&&&&&&");
			for(int j=0;j<POSTS.get(i).pos_wors.size();j++){
				System.out.println(POSTS.get(i).pos_wors.get(j).word+"   ->POST word word");
			}
			System.out.println("&&&&&&&&&&&&MENTION&&&&&&&&&&&&");
			for(int j=0;j<POSTS.get(i).mention.size();j++){
				System.out.println(POSTS.get(i).mention.get(j).number+"   -> post mention");
			}
			System.out.println("&&&&&&&&&&&&ATUHOR&&&&&&&&&&&&");
			for(int j=0;j<POSTS.get(i).pos_author.size();j++){
				System.out.println(POSTS.get(i).pos_author.get(j).number+"   -> pos_author");
			}
			System.out.println("&&&&&&&&&&&&POSTSPOSTS&&&&&&&&&&&&");
			for(int j=0;j<POSTS.get(i).pos_posts.size();j++){
				System.out.println(POSTS.get(i).pos_posts.get(j).number+"   -> post post");
			}
			System.out.println("****************************END*******************************************");
		}
		
		
		
		
	}
	
	public void reconstructSenPostRelations(){
		for(int i=0;i<SENS.size();i++){
			Sentence sentence=SENS.get(i);
			
			int maxNum=-1;
			double max=-1.0;
			for(int j=0;j<sentence.sen_posts.size();j++){
				double sigi=proSiGi(sentence.number,sentence.sen_posts.get(j).number);
				if(max<sigi){
					max=sigi;
					maxNum=sentence.sen_posts.get(j).number;
				}
			}
			
			ArrayList<Post> posts=new ArrayList<Post>(0);
			for(int j=0;j<POSTS.size();j++){
				if(POSTS.get(j).number==maxNum){
					posts.add(POSTS.get(j));
				}
			}
			System.out.println("sensssss");
			System.out.println(i+" | sen is post is"+ maxNum);
			sentence.sen_posts=posts;
			
			SENS.remove(i);
			SENS.add(i,sentence);
		}
	}
	
	//��post word������Ӧ���������
	public void putScoreLdaToObject(double[][] theta,double[][] phi,String[] wordsInLda,int topics){
				
		//�ȿ���words
		for(int i=0;i<wordsInLda.length;i++){
		 	String word=wordsInLda[i];
		 	double[] affi_topic=new double[topics];
		 	//phi to affic array...
		 	for(int j=0;j<topics;j++){
		 	  affi_topic[j]=phi[j][i];	
		 	}
		 	//find the word&give the values...
		 	for(int j=0;j<WORDS.size();j++){
		 		if(WORDS.get(j).word.equals(word)){
		 			//get it
		 			WORDS.get(j).affi_topic=affi_topic;
		 		}
		 	}
		}
		
		// document process
		for(int i=0;i<POSTS.size();i++){
		 double[] affi_topic=new double[topics];
		 
		 for(int j=0;j<topics;j++){
			 affi_topic[j]=theta[i][j];
		 }
		 
		 POSTS.get(i).affi_topic=affi_topic;
		}		
		
		//for(int i=0;i<POSTS.size();i++){
			//for(int j=0;j<POSTS.get(i).affi_topic.length;j++){
				//System.out.print(POSTS.get(i).affi_topic[j]+" | ");
			//}
			//System.out.println();
		//}
		
		//System.out.println("**********************************");
		
		//for(int i=0;i<WORDS.size();i++){
			//for(int j=0;j<WORDS.get(i).affi_topic.length;j++){
				//System.out.print(WORDS.get(i).affi_topic[j]+" | ");
			//}
			//System.out.println();
		//}
		
		//System.out.println("fuck");
		
	} 
	
	//get the shortest path finding algorithm
	
	
	//0 is the host,1 is the hostless...
	public double[] disFromPost(int num_0){
		
		double[] disFromHost=new double[POSTS.size()];
		//System.out.println("disfromHost-> "+ disFromHost.length);
		
		for(int i=0;i<disFromHost.length;i++){
			disFromHost[i]=99999999.0;
		}
		
		disFromHost[num_0]=0;
		
		//boolean findAll=false;
		//ArrayList<Integer> out=new ArrayList<Integer>(0);
		ArrayList<Integer> none=new ArrayList<Integer>(0);
		
		int[] previous=new int[POSTS.size()];
		
		for(int i=0;i<previous.length;i++){
			previous[i]=-1;
		}
		
		int minPos=num_0;
		
		//System.out.println(minPos);
		
	    //yeah.add(num_0);
		
		for(int i=0;i<POSTS.size();i++){			
				none.add(POSTS.get(i).number);			
		}
		
		//for(int i=0;i<none.size();i++){
			//System.out.println(none.get(i));
		//}
		
		//boolean findAll=false;
		//System.out.println(none.size());
		while(none.size()>0){
			minPos=none.get(0);
			for(int j=0;j<none.size();j++){
				//System.out.println(disFromHost[none.get(j)]);
				if(disFromHost[none.get(j)]<disFromHost[minPos]){
					minPos=none.get(j);
				}
			}
			
			//System.out.println(minPos);
			
			if(disFromHost[minPos]==99999999.0)
				break;
			

			Post post=POSTS.get(minPos);
			
			//System.out.println(post.mention.size());
			
			for(int j=0;j<post.mention.size();j++){
				int pp=-1;
				for(int p=0;p<POSTS.size();p++){
					if(POSTS.get(p).number==post.mention.get(j).number)
						pp=p;
				}
				
				//System.out.println(pp);
				
				Post post_2=POSTS.get(pp);
				
				double kl_d=GraphSimDisCompute.dis_doubles_sim(post.affi_topic, post_2.affi_topic);
				
				//System.out.println(kl_d);
				
				double alt=disFromHost[minPos]+kl_d;
				if(alt<disFromHost[pp]){
					disFromHost[pp]=alt;
				    previous[pp]=minPos;	
				}
			}
			
			none.remove(new Integer(minPos));
			//System.out.println(none.size());
			
		}
		
		
		return disFromHost;
	}
	
	
	public double[][] disOfPosts(){
		DIS_posts=new double[POSTS.size()][POSTS.size()];
		
		for(int i=0;i<POSTS.size();i++){
			double[] x=disFromPost(i);
			DIS_posts[i]=x;
		}
		/*
		for(int i=0;i<POSTS.size();i++){
			for(int j=0;j<POSTS.size();j++){
				if(DIS_posts[i][j]<DIS_posts[j][i]){
					DIS_posts[j][i]=DIS_posts[i][j];
				}
			}
		}
		*/
		//System.out.println(num_0+" -> post num");
		/*
		for(int i=0;i<POSTS.size();i++){
			for(int j=0;j<POSTS.size();j++){
			System.out.print(DIS_posts[i][j]+" | ");	
			}
			System.out.println();
		}
		*/
		
		return DIS_posts;
	}
	
	public double proSiGi(int senNum,int postNum){
		Sentence sentence=SENS.get(senNum);
		Post post=POSTS.get(postNum);
		
		ArrayList<Word> words=sentence.sen_words;
		
		//for(int i=0;i<words.size();i++){
			//for(int j=0;j<words.get(i).affi_topic.length;j++){
				//System.out.print(words.get(i).affi_topic[j]+" | ");
			//}
			//System.out.println();
		//}
		
		
		double target=0.0;
		//System.out.println(post.affi_topic.length);
		for(int i=0;i<words.size();i++){
			for(int j=0;j<words.get(0).affi_topic.length;j++){
				target+=(words.get(i).affi_topic[j]*post.affi_topic[j]);
			}
		}
		
		return target;
	}
	
	public double[] sigTopic(double[][] theta,int numOfTopic,int ndocs){
		double[] target=new double[numOfTopic];
		double sum=0.0;
		for(int i=0;i<numOfTopic;i++){
			for(int j=0;j<ndocs;j++){
				target[i]+=theta[j][i];
			}
			sum+=target[i];
		}
		
		//System.out.println(sum+" :sum");
		
		for(int i=0;i<numOfTopic;i++){
			target[i]=target[i]/sum;
		}
		
		//for(int i=0;i<target.length;i++)
			//System.out.println(target[i]);
		return target;
	}
	
	
	public double proGi(int postNum,double[] sigTopic){
		
		Post post=POSTS.get(postNum);
		double target=0.0;
		ArrayList<Word> words=post.pos_wors;
		
		for(int i=0;i<words.size();i++){
			for(int j=0;j<sigTopic.length;j++){
		      target+=(words.get(i).affi_topic[j]*sigTopic[j]);		
			}
		}
		
		return target;
	}
	
	
	
	/*
	 * public ArrayList<Word> constructWord(String INPATH){ BufferedReader
	 * reader; ArrayList<Post> target=new ArrayList<Post>(0); //ArrayList<Sentence>
	 * String topic=""; PosThread thread=new PosThread();
	 * 
	 * try{ reader=new BufferedReader(new FileReader(INPATH));
	 * topic=reader.readLine(); String line=reader.readLine(); int count=0; Post
	 * post=new Post(); post.topic=topic; thread.topic=topic; int num_pos=0;
	 * while(line!=null){ switch(count%5){ case 0:{ post.author=line;
	 * line=reader.readLine(); break; } case 1:{ ArrayList<String>
	 * sens=TransFileToBeans.splitSensFromDoc(line); ArrayList<ArrayList<String>>
	 * sen_wors=TransFileToBeans.splitSensToWords(sens); for(int i=0;i<sen_wors.size();i++){
	 * for(int j=0;j) } } case 2:{} case 3:{} case 4:{} } }
	 * 
	 * }catch(Exception e){ System.out.println(e.getMessage()); } return null; }
	 * 
	 */

	public ArrayList<Word> constructWord(String INPATH) {
		BufferedReader reader;
		// ArrayList<Word> target=new ArrayList<Word>(0);
		// ArrayList<Sentence>
		// PosThread thread=new PosThread();
		try {
			reader = new BufferedReader(new FileReader(INPATH));
			String topic = reader.readLine();
			ArrayList<String> topic_words = TransFileToBeans
					.splitSensToWords(topic);
			int num_word=0;
			if (topic_words.size() > 0) {
				for (int i = 0; i < topic_words.size(); i++) {
					boolean ex_0 = false;
					Word x = new Word();
					int j = 0;
					while ((ex_0 == false) && (j < WORDS.size())) {
						if (topic_words.get(i).equals(WORDS.get(j).word)) {
							ex_0 = true;
							x = WORDS.get(j);
							WORDS.remove(j);
							x.tf++;
							WORDS.add(x);
						}
						j++;
					}

					if (ex_0 == false) {
						x.number=num_word;
						num_word++;
						x.word = topic_words.get(i);
						x.tf = 1;
						WORDS.add(x);
					}
				}
			}
			//����TOPICȡ��...
			/*
			for(int i=0;i<WORDS.size();i++){
				System.out.print(WORDS.get(i).number+"->... NUMBER | ");
				System.out.print(WORDS.get(i).word+"->... WORD | ");
				System.out.print(WORDS.get(i).tf+"->... tf | ");
				System.out.print(WORDS.get(i).wor_wors.size()+"->... WORD words size... |");
				System.out.println();
			}
			*/
			String line = reader.readLine();
			int count = 0;
			while (line != null) {
				if (count % 4 == 1) {
					
                    //System.out.println(line+"/...line"); 
					line=line.replace(',', ' ');
					//line=line.replace(':', ' ');
					ArrayList<String> sens = TransFileToBeans
							.splitSensFromDoc(line);
					ArrayList<ArrayList<String>> sens_wors = TransFileToBeans
							.splitSensToWords(sens);
					//ceshi....
					/*
					for(int i=0;i<sens_wors.size();i++){
                    	if(sens_wors.get(i).size()<=0){
                    		sens_wors.remove(i);
                    	}
                    	//System.out.println();
                    	//System.out.println(sens_wors.get(i).size());
					}
					*/
					
					
					/*
                    for(int i=0;i<sens_wors.size();i++){
                    	for(int j=0;j<sens_wors.get(i).size();j++){
                    		System.out.print(sens_wors.get(i).get(j)+" |");
                    	}
                    	System.out.println();
                   }
                    */
					// ArrayList<String>
					// wors=TransFileToBeans.splitSensToWords(line);

					for (int oi = 0; oi < sens_wors.size(); oi++) {
						for (int i = 0; i < sens_wors.get(oi).size(); i++) {
							String prefix = "";// ǰ��ͬ�ִ�
							//String posteria = "";// ����ͬ�ִ�
							//if (i < sens_wors.get(oi).size() - 1){
								//posteria = sens_wors.get(oi).get(i + 1);
							    //System.out.println(posteria+"  ..posteria of "+sens_wors.get(oi).get(i));
							//}
							if (i > 0){
								prefix = sens_wors.get(oi).get(i - 1);
								//System.out.println(prefix+"  ..prefix of "+sens_wors.get(oi).get(i));
							}
							// ���ص�ǰ��
							boolean exist = false;
							int jj=-1;
							for (int j = 0; j < WORDS.size(); j++) {
								if (sens_wors.get(oi).get(i).equals(
										WORDS.get(j).word)) {
									//System.out.println(WORDS.get(j).word+" |..word... "+WORDS.get(j).number);
									exist = true;
									jj=j;
									break;
									/*
									Word tmp_w = WORDS.get(j);
									tmp_w.tf=(tmp_w.tf)+1;
									System.out.println(tmp_w.tf+"   tf:"+tmp_w.word+" "+i);
									WORDS.remove(j);
									WORDS.add(tmp_w);
								    */
								}
							}
							
							if(exist==true){
								Word tmp_w = WORDS.get(jj);
								tmp_w.tf=(tmp_w.tf)+1;
								//System.out.println(tmp_w.tf+"   tf:"+tmp_w.word+" ");
								WORDS.remove(jj);
								WORDS.add(jj,tmp_w);
							}
							
							
							if (exist == false) {
								Word new_w = new Word();
								new_w.number=num_word;
								num_word++;
								new_w.word = sens_wors.get(oi).get(i);
								new_w.tf = 1;
								WORDS.add(new_w);
								//System.out.println(new_w.word+" ...word false... & * "+new_w.number);
							}
                            
							//System.out.println("****************** prefix post part");
							
							Word cur_w = WORDS.get(WORDS.size() - 1);
							WORDS.remove(WORDS.size() - 1);
                            //System.out.println(cur_w.word+" *ceshi...");
							// ����ǰ��ִ�
							if (!(prefix.equals(""))) {
								//Word pref_w = new Word();
								boolean pre_de = false;
								int jpr = 0;
								while ((pre_de == false)
										&& (jpr < WORDS.size())) {
									if (prefix.equals(WORDS.get(jpr).word)) {
										pre_de = true;
										boolean ex_pre=false;
										boolean ex_cur=false;
										for(int cui=0;cui<cur_w.wor_wors.size();cui++){
											if(cur_w.wor_wors.get(cui).number==WORDS.get(jpr).number)
												ex_pre=true;
										}
										if(ex_pre==false){
										cur_w.wor_wors.add(WORDS.get(jpr));
										}//System.out.println(WORDS.get(jpr).wor_wors.size());
										for(int cui=0;cui<WORDS.get(jpr).wor_wors.size();cui++){
											if(WORDS.get(jpr).wor_wors.get(cui).number==cur_w.number)
												ex_cur=true;
										}
										if(ex_cur==false){
										WORDS.get(jpr).wor_wors.add(cur_w);
										}
										//System.out.println(WORDS.get(jpr).wor_wors.size());
										//WORDS.add(pref_w);
										//WORDS.remove(jpr);
									}
									jpr++;
								}
								/*
								if (pre_de == true) {
									cur_w.wor_wors.add(pref_w);
									pref_w.wor_wors.add(cur_w);
									WORDS.add(pref_w);
                                 */
								} 
								/*
								else {
									pref_w.number=num_word;
									num_word++;
									pref_w.word = prefix;
									// pref_w.wor_wors = new ArrayList<Word>(0);
									pref_w.wor_wors.add(cur_w);
									cur_w.wor_wors.add(pref_w);
									WORDS.add(pref_w);

								}
                              */
							//}
/*
							// ���غ����ִ�
							if (!(posteria.equals(""))) {
								Word post_w = new Word();
								boolean post_de = false;
								int jpr = 0;
								while ((post_de == false)
										&& (jpr < WORDS.size())) {
									if (posteria.equals(WORDS.get(jpr).word)) {
										post_w = WORDS.get(jpr);
										post_de = true;
										WORDS.remove(jpr);
									}
									jpr++;
								}
								if (post_de == true) {
									cur_w.wor_wors.add(post_w);
									post_w.wor_wors.add(cur_w);
									WORDS.add(post_w);

								} else {
									post_w.number=num_word;
									num_word++;
									post_w.word = prefix;
									// pref_w.wor_wors = new ArrayList<Word>(0);
									post_w.wor_wors.add(cur_w);
									cur_w.wor_wors.add(post_w);
									WORDS.add(post_w);

								}
							}
							*/
							
							WORDS.add(cur_w);

						}
						// xx
					}
				}

				line = reader.readLine();
				count++;
			}

			reader.close();

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

		return WORDS;
	}

	public ArrayList<Sentence> constructSens(String INPATH) {
		BufferedReader reader;
		String topic = "";

		try {
			int num_sen=0;
			int num_post=0;
			reader = new BufferedReader(new FileReader(INPATH));
			topic = reader.readLine();
			Post post = new Post();
			post.topic=topic;
			String line = reader.readLine();
			int count = 0;
			while (line != null) {
				//System.out.println(line); 
				if (count % 4 == 0) {
				  
			      post.number=num_post;
			      num_post++;
			      
			      for(int i=0;i<POSTS.size();i++){
						String[] lin=line.split(" ");
						line="";
						for(int ii=0;ii<lin.length;ii++){
							line+=lin[ii];
						}
			      }
			      
                  post.author=line;
                  //System.out.println(post.author);
                  //line=reader.readLine();
				}
				if (count % 4 == 1) {
					//System.out.println(line); 
					line=line.replace(',', ' ');
					//line=line.replace(':', ' ');
					ArrayList<String> sens = TransFileToBeans
							.splitSensFromDoc(line);
					ArrayList<ArrayList<String>> sens_wors = TransFileToBeans
							.splitSensToWords(sens);
					//ArrayList<ArrayList<>>
					
					
					if(sens_wors.size()>1){
					for(int i=0;i<sens_wors.size();i++){
						if(sens_wors.get(i).size()==0){
							sens_wors.remove(i);
							sens.remove(i);
						}
					}
					}
					//for(int i=0;i<sens_wors.size();i++){
                    	//for(int j=0;j<sens_wors.get(i).size();j++){
                    		//System.out.print(sens_wors.get(i).get(j)+" |");                   		
                    	//}
                    	//System.out.println();                   	
					//}
					
					/*
					for(int i=0;i<sens_wors.size();i++){
                    	if(sens_wors.get(i).size()<=0){
                    		sens_wors.remove(i);
                    	}
                    	//System.out.println();
                    	//System.out.println(sens_wors.get(i).size());
					}
					
					*/
					
					for (int i = 0; i < sens_wors.size(); i++) {
						ArrayList<String> cur_sen = sens_wors.get(i);
						boolean de_1 = false;
						Sentence sen_be=new Sentence();
						int be_j=-1;
						
						for (int j = 0; j < SENS.size(); j++) {
							de_1 = MatchArraylist.mathcArraylist(cur_sen, SENS
									.get(j).getSen_words());
							
							//System.out.println(de_1);
							if (de_1 == true) {
                                  sen_be=SENS.get(j);
                                  SENS.remove(j);
                                  be_j=j;
                                  
                                  
                                  sen_be.tf_sen++;
      							post.pos_sens.add(sen_be);
      							sen_be.sen_posts.add(post);
      							
      							//�ھ��ӵĴ��м����post...
      							for(int i_0=0;i_0<sen_be.sen_words.size();i_0++){
      								Word word=sen_be.sen_words.get(i_0);
      								int word_po=FindObjectInWSP.findWordInSen(word.word, WORDS);
      								word=WORDS.get(word_po);
      								WORDS.remove(word_po);
      								boolean xxk=false;
      								for(int j_0=0;j_0<word.wor_posts.size();j_0++){
      									if(post.number==word.wor_posts.get(j_0).number){
      									 	xxk=true;
      										break;
      									}
      								}
      								if(xxk==false){
      							    word.wor_posts.add(post);
      								}
      								boolean xxx=false;
      								for(int j_0=0;j_0<post.pos_wors.size();j_0++){
      								   if(word.word.equals(post.pos_wors.get(j_0).word)){
      									   xxx=true;
      									   break;
      								   }	
      								}
      								if(xxx==false){
      							    post.pos_wors.add(word);
      								}
      								
      							    WORDS.add(word_po,word);
      							    
      							    sen_be.sen_words.remove(i_0);
      							    sen_be.sen_words.add(i_0,word);
      							}
      							SENS.add(be_j, sen_be);
                                  
                                  break;
							}
						}
						
						
						
						
						if(de_1==false){
							//sen_be.sen_posts.add(post);
							
							for(int j=0;j<cur_sen.size();j++){
								Word word_tmp;
								int word_de=FindObjectInWSP.findWordInSen(cur_sen.get(j), WORDS);
								if(word_de!=-1){
									word_tmp=WORDS.get(word_de);
									
									//System.out.println(word_tmp.word+"   ...word & word num is"+word_tmp.number);
									
									WORDS.remove(word_de);
									
									word_tmp.wor_sens.add(sen_be);
									
									boolean xxl=false;
      								for(int j_0=0;j_0<word_tmp.wor_posts.size();j_0++){
      									if(post.number==word_tmp.wor_posts.get(j_0).number){
      									 	xxl=true;
      										break;
      									}
      								}
      								if(xxl==false){
      							    word_tmp.wor_posts.add(post);
      								}
									
									boolean xxx=false;
      								for(int j_0=0;j_0<post.pos_wors.size();j_0++){
      								   if(word_tmp.word.equals(post.pos_wors.get(j_0).word)){
      									   xxx=true;
      									   break;
      								   }	
      								}
									if(xxx==false){
									post.pos_wors.add(word_tmp);
									}
									
									boolean xxk=false;
      								for(int j_0=0;j_0<sen_be.sen_words.size();j_0++){
      								   if(word_tmp.word.equals(sen_be.sen_words.get(j_0).word)){
      									   xxk=true;
      									   break;
      								   }	
      								}
									if(xxk==false){
									sen_be.sen_words.add(word_tmp);
									}
									
									WORDS.add(word_de,word_tmp);
									
								}else{
									System.out.println("failure_x");
								}
							}
							sen_be.number=num_sen;
							num_sen++;
							//System.out.println(sen_be.number);
							sen_be.sen_posts.add(post);
							sen_be.tf_sen=1;
							post.pos_sens.add(sen_be);
							sen_be.sens=sens.get(i);
							SENS.add(sen_be);
						}
					}
				}
				if(count%4==2){
					//System.out.println(line);
					
					if(!(line.equals("null"))){
						ArrayList<Post> men_pos=new ArrayList<Post>(0);
					  	ArrayList<Integer> int_au_po=new ArrayList<Integer>(0);
						for(int i=0;i<POSTS.size();i++){
							String[] lin=line.split(" ");
							line="";
							for(int ii=0;ii<lin.length;ii++){
								line+=lin[ii];
							}
							//System.out.println(line);
					  		if(POSTS.get(i).author.equals(line.trim())){
					  			Integer ii=new Integer(i);
					  			int_au_po.add(ii);
					  		}
					  	}
						for(int i=0;i<int_au_po.size();i++){
							Post post_x=POSTS.get(int_au_po.get(i).intValue());
							men_pos.add(post_x);
							
							post_x.pos_posts.add(post);
							
							POSTS.remove(int_au_po.get(i).intValue());
							POSTS.add(int_au_po.get(i).intValue(),post_x);
						}
						post.mention=men_pos;
					}
				}
				if(count%4==3){
					//System.out.println(line);
					
					String[] time_array=line.split(" ");
					//System.out.println(time_array.length);
					int month=-1;
					String time_0="";
					if(time_array[3].length()>4){
						time_0=time_array[3].substring(0,2)+time_array[3].substring(3);
					}
					else{
					time_0=time_array[3].substring(0,1)+time_array[3].substring(2);
					}
					int time=Integer.parseInt(time_0);
					
					if(time_array[0].equals("Jan"))
						month=1;
					else if(time_array[0].equals("Feb"))
						month=2;
					else if(time_array[0].equals("Mar"))
						month=3;
					else if(time_array[0].equals("Apr"))
						month=4;
					else if(time_array[0].equals("May"))
						month=5;
					else if(time_array[0].equals("Jun"))
						month=6;
					else if(time_array[0].equals("Jul"))
						month=7;
					else if(time_array[0].equals("Aug"))
						month=8;
					else if(time_array[0].equals("Sep"))
						month=9;
					else if(time_array[0].equals("Oct"))
						month=10;
					else if(time_array[0].equals("Nov"))
						month=11;
					else
						month=12;
					if(time_array[4].equals("PM"))
						time+=1200;
					//System.out.println(month);
					
					String x=time_array[2]+month+time_array[1].substring(0,time_array[1].length()-1)+time;
					//System.out.println("FUCK");	
					//System.out.println("FUCK");
					post.time=x;	
					//System.out.println(post.time);
					POSTS.add(post);
					post=new Post();//
				}
				line = reader.readLine();
				count++;
			}
			reader.close();
			/*
			for(int i=0;i<POSTS.size();i++){
				System.out.println(POSTS.get(i).number+" ->pos num");
				System.out.println(POSTS.get(i).pos_wors.size()+"pos wor");
				System.out.println("&&&&&&&&");
			}
			for(int i=0;i<SENS.size();i++){
				System.out.println(SENS.get(i).number);
				System.out.println(SENS.get(i).sen_words.size());
				System.out.println(SENS.get(i).sen_posts.size());
				System.out.println("&&&&&&&&&&&&&&&&");
			}
			*/
			
			for(int i=0;i<POSTS.size();i++){
				if(POSTS.get(i).pos_sens.get(0).sen_words.size()==0){
					Sentence sen=POSTS.get(i).pos_sens.get(0);
					//ȥPOSTS������û�дʵģ����Ҵ����������ɾ��Ҫɾ��������
					if(POSTS.get(i).pos_author.size()>0){						
						for(int j=0;j<POSTS.get(i).pos_author.size();j++){
							//Post post_0=POSTS.get(i).pos_author.get(j);
							for(int ii=0;ii<POSTS.size();ii++){
								if(POSTS.get(ii).number==POSTS.get(i).pos_author.get(j).number){
									POSTS.get(ii).pos_author.remove(POSTS.get(i));
								}
							}
						}
					}
					//System.out.println(POSTS.get(i).mention.size()+"m"+POSTS.get(i).number);
					
					if(POSTS.get(i).mention.size()>0){
						for(int j=0;j<POSTS.get(i).mention.size();j++){
							//Post post_0=POSTS.get(i).pos_author.get(j);
							for(int ii=0;ii<POSTS.size();ii++){
								if(POSTS.get(ii).number==POSTS.get(i).mention.get(j).number){
									POSTS.get(ii).pos_posts.remove(POSTS.get(i));
								}
							}
						}
					}
					
					for(int j=0;j<POSTS.get(i).pos_posts.size();j++){
						for(int ii=0;ii<POSTS.size();ii++){
							if(POSTS.get(ii).number==POSTS.get(i).pos_posts.get(j).number){
								POSTS.get(ii).mention.remove(POSTS.get(i));
							}
						}
						
					}
					
					
					POSTS.remove(i);
					
					//delete sens
					System.out.println();
					for(int j=0;j<SENS.size();j++){
						if(SENS.get(j).number ==sen.number){
							Sentence sentence=SENS.get(j);
							
							if(sentence.sen_as.size()>0){
								for(int ij=0;ij<sentence.sen_as.size();ij++){								
									for(int ii=0;ii<SENS.size();ii++){
									 if(SENS.get(ii).number==sentence.sen_as.get(ij).number){
									   SENS.get(ii).sen_as.remove(SENS.get(j));
									 }
								    }							
								}
							}
							
							
							SENS.remove(j);		
						}
					}
				}
			}
			
			//sens de chuli
			/*
			System.out.println(SENS.get(3).sen_words.size()+"fuck");
			for(int i=0;i<SENS.size();i++){
				if(SENS.get(i).sen_words.size()==0){
					
					if(SENS.get(i).sen_as.size()>0){
						for(int j=0;j<SENS.get(i).sen_as.size();j++){
							for(int ii=0;ii<SENS.size();ii++){
								if(SENS.get(ii).number==SENS.get(i).sen_as.get(j).number){
									SENS.get(ii).sen_as.remove(SENS.get(i));
								}
							}
						}
					}
					
					if(SENS.get(i).sen_posts.size()>0){
						for(int j=0;j<SENS.get(i).sen_posts.size();j++){
							for(int ii=0;ii<POSTS.size();ii++){
								if(POSTS.get(ii).number==SENS.get(i).sen_posts.get(j).number){
									POSTS.get(ii).pos_sens.remove(SENS.get(i));
								}
							}
						}
					}
					
					
					
					if(SENS.get(i).sen_sens.size()>0){
						for(int j=0;j<SENS.get(i).sen_sens.size();j++){
							
							for(int ii=0;ii<SENS.size();ii++){
								if(SENS.get(ii).number==SENS.get(i).sen_sens.get(j).number){
																		
										SENS.get(ii).sen_sens.remove(SENS.get(i));									
								}
							}	
						}
					}
					
					SENS.remove(i);
				}
			}
			*/
			///....
			
			
			
			
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return SENS;
	}
	
	
	
	
	
	//���Ӿ��Ӻʹ��м��������ϵ
	public void addCommunSenWorPos(){
		//��Ҫ����WORDS SENS ��ʱ���������ϵ��
		
		//words process
		for(int i=0;i<WORDS.size();i++){
			Word word=WORDS.get(i);
			WORDS.remove(i);
		    
			for(int j=0;j<word.wor_posts.size();j++){
				String author=word.wor_posts.get(j).author;
				String time=word.wor_posts.get(j).time;
				boolean t=false;
				boolean a=false;
				for(int ii=0;ii<word.wor_time.size();ii++){
					if(word.wor_time.get(ii).equals(time)){
						t=true;
						break;
					}
				}
				if(t==false){
					word.wor_time.add(time);
				}
				
				for(int ii=0;ii<word.wor_author.size();ii++){
					if(word.wor_author.get(ii).equals(author)){
					 a=true;
					 break;
					}
				}
				if(a==false){
					word.wor_author.add(author);
				}
				AuthorTime at=new AuthorTime(author,time);
				boolean att=MatchArraylist.matchAtFromAts(word.wor_at, at);
				if(att==false){
					word.wor_at.add(at);
				}
				
				
			}
			
			
			WORDS.add(i,word);
		}
		
		//�㶨post the same author posts
		for(int i=0;i<POSTS.size();i++){
		 Post post=POSTS.get(i);
		 POSTS.remove(i);
		 
		 for(int j=0;j<POSTS.size();j++){
			 if((POSTS.get(j).author.equals(post.author))&&(POSTS.get(j).number!=post.number)){
				 post.pos_author.add(POSTS.get(j));
			 }
		 }
		 
		 POSTS.add(i,post);
		}
		
		//sen process
		
		for(int i=0;i<SENS.size();i++){
			
			Sentence sen=SENS.get(i);
			SENS.remove(i);
			//����ʱ���������
			for(int j=0;j<sen.sen_posts.size();j++){
				String author=sen.sen_posts.get(j).author;
				String time=sen.sen_posts.get(j).time;
				
				boolean t=false;
				boolean a=false;
				for(int ii=0;ii<sen.sen_time.size();ii++){
					if(sen.sen_time.get(ii).equals(time)){
						t=true;
						break;
					}
				}
				if(t==false){
					sen.sen_time.add(time);
				}
				
				for(int ii=0;ii<sen.sen_author.size();ii++){
					if(sen.sen_author.get(ii).equals(author)){
					 a=true;
					 break;
					}
				}
				if(a==false){
					sen.sen_author.add(author);
				}
				AuthorTime at=new AuthorTime(author,time);
				boolean att=MatchArraylist.matchAtFromAts(sen.sen_at, at);
				if(att==false){
					sen.sen_at.add(at);
				}				
			}
			
			
			
			
			//������Ӽ���ϵ
			//���־���
			for(int j=0;j<sen.sen_posts.size();j++){
				ArrayList<Sentence> sen_simus=sen.sen_posts.get(j).pos_sens;
				
				for(int ii=0;ii<sen_simus.size();ii++){
					if(sen_simus.get(ii).number!=sen.number){
						boolean ssim=false;
						for(int ij=0;ij<sen.sen_sens.size();ij++){
						 	if(sen.sen_sens.get(ij).number==sen_simus.get(ii).number){
						 		ssim=true;
						 	}
						}
						if(ssim==false){
							sen.sen_sens.add(sen_simus.get(ii));
						}
					}
				}
				
			}
			
			//ʵ�ֻظ��������� //?���ظ��Ļ���Ҫ������ô��...Ŀǰ��NOT�����ӵ�//
			for(int j=0;j<sen.sen_posts.size();j++){
				ArrayList<Post> pos_men=sen.sen_posts.get(j).mention;
				//ArrayList<Post> pos_pos=sen.sen_posts.get(j).pos_posts;
				
				for(int ii=0;ii<pos_men.size();ii++){
					ArrayList<Sentence> sen_men=pos_men.get(ii).pos_sens;
					for(int ij=0;ij<sen_men.size();ij++){
						boolean xx=false;
						for(int jj=0;jj<sen.sen_res.size();jj++){
							if(sen.sen_res.get(jj).number==sen_men.get(ij).number){
								xx=true;
							}
						}
						if(xx==false){
							sen.sen_res.add(sen_men.get(ij));
						}
					}
				}
				/*
				for(int ii=0;ii<pos_pos.size();ii++){
					ArrayList<Sentence> sen_pos=pos_pos.get(ii).pos_sens;
					for(int ij=0;ij<sen_pos.size();ij++){
						boolean xx=false;
						for(int jj=0;jj<sen.sen_res.size();jj++){
							if(sen.sen_res.get(jj).number==sen_pos.get(ij).number){
								xx=true;
							}
						}
						if(xx==false){
							sen.sen_res.add(sen_pos.get(ij));
						}
					}
				}	
				
				*/
			}
			
			//sentence add array about author
			for(int j=0;j<sen.sen_posts.size();j++){
				ArrayList<Post> pos_au=sen.sen_posts.get(j).pos_author;
				
				for(int ii=0;ii<pos_au.size();ii++){
					ArrayList<Sentence> sen_auu=pos_au.get(ii).pos_sens;
					for(int ij=0;ij<sen_auu.size();ij++){
						boolean xx=false;
						for(int jj=0;jj<sen.sen_as.size();jj++){
							if(sen.sen_as.get(jj).number==sen_auu.get(ij).number){
								xx=true;
							}
						}
						if(xx==false){
							sen.sen_as.add(sen_auu.get(ij));
						}
					}
					
				}
				
                ArrayList<Sentence> sen_simus=sen.sen_posts.get(j).pos_sens;
				
				for(int ii=0;ii<sen_simus.size();ii++){
					if(sen_simus.get(ii).number!=sen.number){
						boolean ssim=false;
						for(int ij=0;ij<sen.sen_as.size();ij++){
						 	if(sen.sen_as.get(ij).number==sen_simus.get(ii).number){
						 		ssim=true;
						 	}
						}
						if(ssim==false){
							sen.sen_as.add(sen_simus.get(ii));
						}
					}
				}
				
				
			}
			
			SENS.add(i,sen);
		}
	}
	
	//ȥ�����ӣ��������Լ����ǹ�ϵ�е��������� actually it is no use now....
	public void DeleteJunks(){
		//sens process
		for(int i=0;i<SENS.size();i++){
			Sentence sentence=SENS.get(i);
		    ArrayList<Integer> int_sentence_find=FindObjectInWSP.matchSenInSens(sentence, SENS);	
		    for(int j=0;j<int_sentence_find.size();j++){
		    	int posi_sen=int_sentence_find.get(j);
		    	if(posi_sen!=i){
		    		Sentence sentence_0=SENS.get(posi_sen);
		    		SENS.remove(posi_sen);
		    		for(int jj=0;jj<sentence_0.sen_posts.size();jj++){
		    			if(!(sentence.sen_posts.contains(sentence_0.sen_posts.get(jj)))){
		    				Post post=sentence_0.sen_posts.get(jj);
		    				sentence.sen_posts.add(sentence_0.sen_posts.get(jj));
		    				int po_0=post.pos_sens.indexOf(sentence_0);
		    				post.pos_sens.remove(sentence_0);
		    				post.pos_sens.add(po_0,sentence);
		    			}
		    		}
		    		sentence.tf_sen+=sentence_0.tf_sen;
		    		
		    	}
		    }
			SENS.remove(i);
			SENS.add(sentence);
		}
		
		/*
		//posts process....��Ҫ�Ƕ������й������ӽ�����������
		for(int i=0;i<POSTS.size();i++){
			Post post=POSTS.get(i);
			
			ArrayList<Post> post_pos=post.pos_posts;
			ArrayList<Post> post_men=post.mention;
			
			for(int j=0;j<post_pos.size();j++){
				Post post_0=post_pos.get(j);
				boolean xx=false;
				ArrayList<Integer>
				for(int jj=j+1;jj<post_pos.size();jj++){
					if(post_pos.get(jj).number==post_0.number){
						xx=true;
					}
				}
			}
			
		}
		*/
		
	}
	
	
	public static void main(String[] args){
		ConstructBeans constructBeans=new ConstructBeans();
		constructBeans.constructWord("E:\\WORK\\My Paper\\ExperimentData\\PRocess\\A154381353.txt");
		
		
		constructBeans.constructSens("E:\\WORK\\My Paper\\ExperimentData\\PRocess\\A154381353.txt");
		constructBeans.addCommunSenWorPos();
		
		//System.out.println(constructBeans.POSTS.get(1).pos_sens.get(0).sen_words.size()+" size");
	
	    /*  
		System.out.println(constructBeans.SENS.size());
		System.out.println("****************************SEN**********************************");
		for(int i=0;i<constructBeans.SENS.size();i++){
		 System.out.print(constructBeans.SENS.get(i).number+"  ...-> sen num... |  ");
		 System.out.print(constructBeans.SENS.get(i).tf_sen+"  ...-> sen tf... |  ");
		 System.out.print(constructBeans.SENS.get(i).sen_posts.size()+"  ...-> sen post size... |  ");
		 System.out.print(constructBeans.SENS.get(i).sen_words.size()+"  ...-> sen word size... |  ");
		 System.out.println();
		 System.out.println(constructBeans.SENS.get(i).sens+"----SENS---");
		 System.out.println();
		 for(int j=0;j<constructBeans.SENS.get(i).sen_words.size();j++){
			 System.out.print("      SEN_wors"+j+" ... -> ");
			System.out.println(constructBeans.SENS.get(i).sen_words.get(j).word);
		 }
		 System.out.println("******************************sen as  SEN AS*******************************");
		 for(int j=0;j<constructBeans.SENS.get(i).sen_as.size();j++){
			 System.out.print("      SEN_sen as"+j+" ... -> ");
			 System.out.println(constructBeans.SENS.get(i).sen_as.get(j).number);
		 }
		 System.out.println("*************************RES*****************************************");
		 for(int j=0;j<constructBeans.SENS.get(i).sen_res.size();j++){
			 System.out.print("      SEN_sen res"+j+" ... -> ");
			 System.out.println(constructBeans.SENS.get(i).sen_res.get(j).number);
		 }
		 System.out.println("*************************sens*****************************************");
		 for(int j=0;j<constructBeans.SENS.get(i).sen_sens.size();j++){
			 System.out.print("      SEN_sen sens"+j+" ... -> ");
			 System.out.println(constructBeans.SENS.get(i).sen_sens.get(j).number);
		 }
		 System.out.println("*************************posts*****************************************");
		 for(int j=0;j<constructBeans.SENS.get(i).sen_posts.size();j++){
			 System.out.print("      SEN_sen_posts"+j+" ... -> ");
			 System.out.println(constructBeans.SENS.get(i).sen_posts.get(j).number);
		 }
		 System.out.println("*************************time*****************************************");
		 for(int j=0;j<constructBeans.SENS.get(i).sen_time.size();j++){
			 System.out.print("      SEN_sen time"+j+" ... -> ");
			 System.out.println(constructBeans.SENS.get(i).sen_time.get(j));
		 }
		 System.out.println("*************************author*****************************************");
		 for(int j=0;j<constructBeans.SENS.get(i).sen_author.size();j++){
			 System.out.print("      SEN_sen auhor"+j+" ... -> ");
			 System.out.println(constructBeans.SENS.get(i).sen_author.get(j));
		 }
		}
		*/
		
		/*
		System.out.println("****************************************************************************");
		System.out.println("****************************************************************************");
		System.out.println(constructBeans.WORDS.size()+"->...WORD NUMBER;");
		for(int i=0;i<constructBeans.WORDS.size();i++){
			System.out.print(constructBeans.WORDS.get(i).number+"->... NUMBER | ");
			System.out.print(constructBeans.WORDS.get(i).word+"->... WORD | ");
			System.out.print(constructBeans.WORDS.get(i).tf+"->... tf | ");
			System.out.print(constructBeans.WORDS.get(i).wor_wors.size()+"->... WORD words size... |");
			System.out.println();
			for(int j=0;j<constructBeans.WORDS.get(i).wor_wors.size();j++){
				System.out.print("      WORD_wors"+j+" ... -> ");
				System.out.println(constructBeans.WORDS.get(i).wor_wors.get(j).word);
			}
			System.out.println("****************************************************************************");
			for(int j=0;j<constructBeans.WORDS.get(i).wor_sens.size();j++){
				System.out.print("      WORD_sens"+j+" ... -> ");
				System.out.println(constructBeans.WORDS.get(i).wor_sens.get(j).number);
			}
			
			System.out.println("****************************************************************************");
		    
		}
		
		*/
		
		//System.out.println("POST SIZE"+ constructBeans.POSTS.size());
		
		System.out.println("*********%%%%%*******************POSTS************************************************");
		for(int i=0;i<constructBeans.POSTS.size();i++){
			System.out.println("****************************************************************************");
			System.out.print(constructBeans.POSTS.get(i).number+"    ->number    |");
			System.out.print(constructBeans.POSTS.get(i).topic+"     ->topic     |");
			System.out.print(constructBeans.POSTS.get(i).author+"    ->author    |");
			System.out.print(constructBeans.POSTS.get(i).time+"      ->time    |");
			//System.out.print(constructBeans.POSTS.get(i).pos_sens.size+" ->sens size");
			System.out.println("&&&&&&&&&&&SENS&&&&&&&&&&&&&");
			for(int j=0;j<constructBeans.POSTS.get(i).pos_sens.size();j++){
				System.out.println(constructBeans.POSTS.get(i).pos_sens.get(j).number+"   ->POST SEN NUM");
			}
			System.out.println("&&&&&&&&&&&POSTS&&&&&&&&&&&&&");
			for(int j=0;j<constructBeans.POSTS.get(i).pos_wors.size();j++){
				System.out.println(constructBeans.POSTS.get(i).pos_wors.get(j).word+"   ->POST word word");
			}
			System.out.println("&&&&&&&&&&&&MENTION&&&&&&&&&&&&");
			for(int j=0;j<constructBeans.POSTS.get(i).mention.size();j++){
				System.out.println(constructBeans.POSTS.get(i).mention.get(j).number+"   -> post mention");
			}
			System.out.println("&&&&&&&&&&&&ATUHOR&&&&&&&&&&&&");
			for(int j=0;j<constructBeans.POSTS.get(i).pos_author.size();j++){
				System.out.println(constructBeans.POSTS.get(i).pos_author.get(j).number+"   -> pos_author");
			}
			System.out.println("&&&&&&&&&&&&POSTSPOSTS&&&&&&&&&&&&");
			for(int j=0;j<constructBeans.POSTS.get(i).pos_posts.size();j++){
				System.out.println(constructBeans.POSTS.get(i).pos_posts.get(j).number+"   -> post post");
			}
			System.out.println("****************************END*******************************************");
		}
		
	
	}
	

}
