package preTm;
import  beans.*;
import preTm.*;
import java.util.*;
public class FindObjectInWSP {
 //public static int word_de=-1;
 public static int findWordInSen(String word_0,ArrayList<Word> words){
	 int word_de=-1;
	 int word_dee=0;
	 Word word=new Word();
	 boolean de_2=false;
	 while((de_2==false)&&(word_dee<words.size())){
		 if(word_0.equals(words.get(word_dee).word)){
			 de_2=true;
			 word_de=word_dee;
		 }else{
			 word_dee++;
		 }
	 }
	 
	 
	 if(de_2==true){
		 //System.out.println(word_de);
		 return word_de;
	 }else{
		 return -1;
	 }
	 //return word;
 }
 
 
 public static ArrayList<Integer> matchSenInSens(Sentence sentence,ArrayList<Sentence> sens){
	 ArrayList<Integer> tar_ints=new ArrayList<Integer>(0);
	 
	 for(int i=0;i<sens.size();i++){
		 Sentence sen=sens.get(i);
		 ArrayList<Word> words_2=sen.getSen_words();
		 ArrayList<Word> words_1=sentence.getSen_words();
		 boolean check=true;
		 if(words_1.size()==words_2.size()){
			 for(int j=0;j<words_1.size();j++){
				 if(!(words_1.get(j).word.equals(words_2.get(j).word))){
					check=false;
					 break;
				 }
			 }
		 }else{
			 check=false;
		 }
		 if(check==true){
			 tar_ints.add(i);
		 }
	 }
	 
	 return tar_ints;
 }
 /*
 public static ArrayList<Integer> matchPosInPost(Post post,ArrayList<Post> posts){
     ArrayList<Integer> tar_ints=new ArrayList<Integer>(0);
	 
	 for(int i=0;i<posts.size();i++){
		 Post post=posts.get(i);
		 ArrayList<Word> words_2=sen.getSen_words();
		 ArrayList<Word> words_1=sentence.getSen_words();
		 boolean check=true;
		 if(words_1.size()==words_2.size()){
			 for(int j=0;j<words_1.size();j++){
				 if(!(words_1.get(j).word.equals(words_2.get(j).word))){
					check=false;
					 break;
				 }
			 }
		 }else{
			 check=false;
		 }
		 if(check==true){
			 tar_ints.add(i);
		 }
	 }
	 
	 return tar_ints;
	 
	 
	 return null;
 }
 */
 
 public static int findSenInSens(ArrayList<String> sens,ArrayList<Sentence> sentences){
	 
	 for(int i=0;i<sentences.size();i++){
		 boolean x_tar=true;
		 Sentence sen=sentences.get(i);
		 //ArrayList<String> sen_tar=new ArrayList<String>(0);
		 ArrayList<Word> words=sen.getSen_words();
		 ArrayList<String> words_1=new ArrayList<String>(0);
		 for(int j=0;j<words.size();j++){
			 words_1.add(words.get(j).word);
		 }
		 for(int j=0;j<sens.size();j++){
			 if(!(words_1.contains(sens.get(j)))){
				 x_tar=false;
				 break;
			 }
		 }
		 if(x_tar==true){
			 return i;
		 }
	 }
	 return -1;
 }
 
 public static ArrayList<Word> deleteJunkWord(ArrayList<Word> words){
	 
	 for(int i=0;i<words.size();i++){
		 Word word_1=words.get(i);
		 
		 for(int j=i+1;j<words.size();j++){
			Word word_2=words.get(j);
			if(word_1.word.equals(word_2.getWord())){
				
				word_1.tf+=word_2.tf;
				for(int z=0;z<word_2.wor_wors.size();z++){
					//word_1.wor_wors.add(word_2.wor_wors.get(z));
					Word word_3=word_2.wor_wors.get(z);
				    if(word_3.wor_wors.contains(word_2))
				    	word_3.wor_wors.remove(word_2);
				    word_3.wor_wors.add(word_1);
				}
				words.remove(j);
			}
		 }
		 for(int j=0;j<word_1.wor_wors.size();j++){
			 //find word_1 wor_wors the junk words...
			 Word  word_4=word_1.wor_wors.get(j);
			 for(int jj=j+1;jj<word_1.wor_wors.size();jj++){
				 if(word_4.word.equals(word_1.wor_wors.get(jj).word)){
					 word_1.wor_wors.remove(jj);
				 }
			 }
		 }
		 
		 words.remove(i);
		 words.add(i,word_1);
	 }
	 
	 
	 return words;
 }
 
 
}
