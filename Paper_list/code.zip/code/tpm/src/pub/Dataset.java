
package pub;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;
  
public class Dataset {
	
	// just estimate the whole thread
	
	public int V;			 		// number of words
	
	public Dictionary globalDict;	 		
	
	//--------------------------------------------------------------
	// Constructor
	//--------------------------------------------------------------
	public Dataset(){
		//localDict = new Dictionary();
		V = 0;
		globalDict = new Dictionary();
		//lid2gid = null;
	}
	
	
	
	//-------------------------------------------------------------
	//Public Instance Methods
	//-------------------------------------------------------------
	
	/**
	 * set the document at the index idx if idx is greater than 0 and less than M
	 * @param str string contains doc
	 * @param idx index in the document array
	 */
	public void setDoc(String str, int idx){
		
			String [] words = str.split("[ \\t\\n]");		
			for (String word : words){
				int _id = globalDict.word2id.size();
				
				if (globalDict.contains(word))		
					_id = globalDict.getID(word);
				else{
					globalDict.addWord(word);
				}			
			}
			V = globalDict.word2id.size();					
	}
	//---------------------------------------------------------------
	// I/O methods
	//---------------------------------------------------------------
	
	/**
	 *  read a dataset from a stream, create new dictionary
	 *  @return dataset if success and null otherwise
	 */
	public static Dataset readDataSet(String filename){
		try {
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					new FileInputStream(filename), "UTF-8"));
			Dataset data = readDataSet(reader);
			reader.close();
			return data;
		}
		catch (Exception e){
			System.out.println("Read Dataset Error: " + e.getMessage());
			e.printStackTrace();
			return null;
		}
	}
	
	
	/**
	 *  read a dataset from a stream, create new dictionary
	 *  @return dataset if success and null otherwise
	 */
	public static Dataset readDataSet(BufferedReader reader){
		try {
			//read number of document
			String line;
			line = reader.readLine();
			int M = Integer.parseInt(line);
			//M is the number of docs, as the lines
			
			Dataset data = new Dataset();
			
			for (int i = 0; i < M; ++i){
				line = reader.readLine();
				data.setDoc(line, i);
			}
			
			return data;
		}
		catch (Exception e){
			System.out.println("Read Dataset Error: " + e.getMessage());
			e.printStackTrace();
			return null;
		}
	}
	
	
}
