package cur;

import java.util.HashMap;
import java.util.Map;
import java.util.Vector;
import java.io.*;

import pub.*;
  
public class LocalDataset {
	public Document [][] docs; //U
	public Document [][] can_docs; //U
	public int[] M;
	public int[] MC;
	public int V;
	public Dictionary globalDict;
	
	public LocalDataset(){
		M = null;
		MC = null;
		V = 0;
		docs = null;
		can_docs =  null;
		globalDict = null;
	}
	
	public void setDoc(String str, int udx, int idx){
		if (0 <= idx && idx < M[udx]){
			String [] words = str.split("[ \\t\\n]");
			Vector<Integer> ids = new Vector<Integer>();
			for (String word : words){
				if (globalDict.contains(word)){		
					Integer id = globalDict.getID(word);	
					if (id != null){
						ids.add(id);
					}
				}
			}
			Document doc = new Document(ids, str);
			docs[udx][idx] = doc;		
		}
	}
	
	public void setCanDoc(String str, int udx, int idx){
		if (0 <= idx && idx < MC[udx]){
			String [] words = str.split("[ \\t\\n]");
			Vector<Integer> ids = new Vector<Integer>();
			for (String word : words){
				if (globalDict.contains(word)){		
					Integer id = globalDict.getID(word);	
					if (id != null){
						ids.add(id);
					}
				}
			}
			Document doc = new Document(ids, str);
			can_docs[udx][idx] = doc;		
		}
	}
	
	
	
	public static LocalDataset readDataSet(int nusers, String dir, Dictionary dict){
		try {
			
			LocalDataset data = new LocalDataset();
			data.globalDict=dict;
			data.V=dict.word2id.size();
			data.docs=new Document[nusers][];
			data.can_docs=new Document[nusers][];
			data.M=new int[nusers];
			data.MC=new int[nusers];
			
			for(int i=0;i<nusers;i++){
				//1. read user file...
				BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(dir+"/"+i+".txt"), "UTF-8"));
				
				//System.out.println(dir+"/"+i+".txt");
				
				String line=null;
				line = reader.readLine();
				int M = Integer.parseInt(line);
				data.M[i]=M;
				data.docs[i]=new Document[M];
				
				for (int j = 0; j < M; j++){
					line = reader.readLine();
					data.setDoc(line,i,j);
				}
				
				reader.close();
				
				//2. read candidate file...
				reader = new BufferedReader(new InputStreamReader(new FileInputStream(dir+"/"+i+".can"), "UTF-8"));
				line=null;
				line = reader.readLine();
				int MC = Integer.parseInt(line);
				data.MC[i]=MC;
				data.can_docs[i]=new Document[MC];
				
				for (int j = 0; j < MC; j++){
					line = reader.readLine();
					data.setCanDoc(line,i,j);
				}
			
				reader.close();
				
			}
			
			return data;
		}
		catch (Exception e){
			System.out.println("Read Dataset Error: " + e.getMessage());
			e.printStackTrace();
			return null;
		}
	}
	
	
}
