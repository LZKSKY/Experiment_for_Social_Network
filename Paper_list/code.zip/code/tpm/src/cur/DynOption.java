package cur;
import org.kohsuke.args4j.*;
public class DynOption {
	
	@Option(name="-dir", usage="Specify directory")
	public String dir = "";
	
	@Option(name="-predir", usage="Specify previouss directory")
	public String predir = "";
	
	@Option(name="-nusers", usage="Specify data file")
	public int nuser = 0;
	
	@Option(name="-model", usage="Specify the model name")
	public String modelName = "";
	
	@Option(name="-org", usage="Specify the org index")
	public String org="0";
	
	@Option(name="-relSlices", usage="Specify relSlices")
	public int relSlices = 1;
	
	@Option(name="-ntopics", usage="Specify the number of topics")
	public int K = 100;
	
	@Option(name="-nctopics", usage="Specify the number of common topics")
	public int CK= 100;
	
	@Option(name="-nbtopics", usage ="Specify the number of burst topics")
	public int BK = 10;
	
	@Option(name="-niters", usage="Specify the number of iterations")
	public int niters = 1000;
	
	@Option(name="-globalDicFile", usage="Specify the globalDicFile")
	public String globalDicFile="";
	
	@Option(name="-wordmap", usage="Specify the wordmap file")
	public String wordMapFileName = "wordmap.txt";
	
}
