package cur;
import java.io.File;
import java.util.Vector;
import umontreal.iro.lecuyer.util.*;
import java.lang.*;
import java.math.BigDecimal;

  
public class SliEstor {
	
	//estimate the current time slice corpus
	public Model trnModel;
	public DynOption option;
	
	public double betab=0.1;
	public double alpha=0.0;
	public double alphab=0.0;
	public double sigma=0.3;
	public double gamma=0.3;
	
	public double[] Vbeta;
	public double[] Vbetac;
	public double[] Kalphac;
	
	public boolean init(DynOption option){
		this.option = option;
		trnModel = new Model();
		
		trnModel.initNewModel(option);
		
		int numT=trnModel.K;	
		alpha=50.0/numT;
		alphab = 50.0/trnModel.BK;
		sigma=trnModel.sigma;
		gamma=trnModel.gamma;
		
		Vbeta = new double[trnModel.K];
		Vbetac = new double[trnModel.CK];
		Kalphac = new double[trnModel.U];
		
		return true;
	}
	
	public void estimate(){
		
		int liter=0;
		for (liter = 0; liter < trnModel.niters; liter++){
			System.out.println("The"+liter+"th iteration....");
			for(int u=0;u<trnModel.U;u++){
				
				//E-step...
				// for all z_i
				for (int m = 0; m < trnModel.M[u]; m++){				
					for (int n = 0; n < trnModel.data.docs[u][m].length; n++){
						
						// sample from p(z_i|z_-i, w)
						int topic = sampling(u, m, n);
						trnModel.z[u][m].set(n, topic);
					}// end for each word
				}// end for each document
				
				//step2: for candidate file...
				for (int m = 0; m < trnModel.MC[u]; m++){				
					for (int n = 0; n < trnModel.data.can_docs[u][m].length; n++){
						// sample from p(z_i|z_-i, w)
						int topic = samplingf(u, m, n);
						trnModel.zf[u][m].set(n, topic);
					}// end for each word
				}// end for each document
			}
			
			// M step...
			recAlphac();
			recBeta();
			recBetac();
			
		}// end iterations		
		
		System.out.println("Gibbs sampling completed!\n");
		System.out.println("Saving the final model!\n");
		
		computeTheta();
		computePhi();
		for(int u=0;u<trnModel.U;u++){
			trnModel.saveModel(u);
		}
		trnModel.saveModelPhi(trnModel.dir + "/model" + trnModel.phiSuffix);
		trnModel.saveModelPhib(trnModel.dir + "/model" + trnModel.phiSuffixb);
	}
	
	/**
	 * Do sampling
	 * @param m document number
	 * @param n word number
	 * @return topic id
	 */
	public int sampling(int u, int m, int n){ 
		//N define the index number of the word in the document to the index of the local dataset in the whole corpus
		// remove z_i from the count variable
		int topic = trnModel.z[u][m].get(n); //the index of the topic
		int w = trnModel.data.docs[u][m].words[n]; // word index in the global dataset
	
		double asigma=3*sigma;
		double agamma=3*gamma;
		double Vbetab = trnModel.V * betab;
		double Kalpha = trnModel.K * alpha;
		double Kalphab = trnModel.BK * alphab;
		
		
		for(int i=0;i<trnModel.K;i++){
			Vbeta[i]=0.1;
			Vbeta[i]=(trnModel.beta[i])*trnModel.V;
		}
		
		for(int i=0;i<trnModel.CK;i++){
			Vbetac[i]=0.1;
			Vbetac[i]=(trnModel.betac[i])*trnModel.V;
		}
		
		for(int i=0;i<trnModel.U;i++){
			Kalphac[i]=0.0;
			for(int z=0;z<trnModel.CK;z++){
				Kalphac[i]+=trnModel.alphac[i][z];
			}
		}
		
		//do multinominal sampling via cumulative method    	E step...
		double[] pe=new double[3];
		for(int c=0;c<3;c++){
			pe[c]=(trnModel.ndca[u][m][c]+sigma)/(trnModel.ndsum[u][m]+asigma);
		}
		pe[1]=pe[1]+pe[0];
		pe[2]=pe[1]+pe[2];
		
		double ue=Math.random()*pe[2];
		
		int ee=2; //default: burst topic...
		if(ue<pe[0]){
			ee=0; //user topic...
		}else if(ue<pe[1]){
			ee=1;
		}else{
			ee=2;
		}
		
		if(ee==0){
			//for each user topic...
			
			for (int k = 0; k < trnModel.K; k++){
				trnModel.p[k]=0.0;
				double opt_beta=0.0;
				opt_beta=trnModel.beta[k]*trnModel.prePhi[k][w];
				trnModel.p[k] = ((trnModel.nw[w][k] + opt_beta)/(trnModel.nwsum[k] + Vbeta[k])) * (trnModel.nd[u][m][k] + trnModel.alpha*trnModel.preTheta[u][k])/(trnModel.ndsum[u][m] + Kalpha);
			}
			
			// cumulate multinomial parameters
			for (int k = 1; k < trnModel.K; k++){
				trnModel.p[k] += trnModel.p[k-1];
			}
			
			// scaled sample because of unnormalized p[]
	     	double uk = Math.random() * trnModel.p[trnModel.K - 1];
		 	
	     	for (topic = 0; topic < trnModel.K; topic++){
				if (trnModel.p[topic] > uk) //sample topic w.r.t distribution p
					break;
			}
			if(topic==trnModel.K)
				topic--;
			// add newly estimated z_i to count variables
			trnModel.nw[w][topic] += 1;
			trnModel.nd[u][m][topic] += 1;
			trnModel.nwsum[topic] += 1;
			trnModel.ndsum[u][m] += 1;
			trnModel.ndca[u][m][0]+=1;
	     	
		}else if(ee==1){
			for (int k = 0; k < trnModel.CK; k++){
				trnModel.pc[k]=0.0;
				double opt_beta=0.0;
				opt_beta=trnModel.betac[k]*trnModel.prePhic[k][w];
				trnModel.pc[k] = ((trnModel.nwc[w][k] + opt_beta)/(trnModel.nwsumc[k] + Vbetac[k])) * (trnModel.ndc[u][m][k] + trnModel.alphac[u][k]*trnModel.preThetac[u][k])/(trnModel.ndsum[u][m] + Kalphac[u]);
			}
			
			// cumulate multinomial parameters
			for (int k = 1; k < trnModel.CK; k++){
				trnModel.pc[k] += trnModel.pc[k-1];
			}
			
			// scaled sample because of unnormalized p[]
	     	double uk = Math.random() * trnModel.pc[trnModel.CK - 1];
		 	
	     	for (topic = 0; topic < trnModel.CK; topic++){
				if (trnModel.pc[topic] > uk) //sample topic w.r.t distribution p
					break;
			}
	     	if(topic==trnModel.CK)
				topic--;
			// add newly estimated z_i to count variables
			trnModel.nwc[w][topic] += 1;
			trnModel.ndc[u][m][topic] += 1;
			trnModel.nwsumc[topic] += 1;
			trnModel.ndsum[u][m] += 1;
			trnModel.ndca[u][m][1]+=1;
			
			topic =  topic+trnModel.K;
			
		}else{
			for (int k = 0; k < trnModel.BK; k++){
				trnModel.pb[k]=0.0;
				trnModel.pb[k] = (trnModel.nwb[w][k] + betab)/(trnModel.nwsumb[k] + Vbetab) * (trnModel.ndb[u][m][k] + trnModel.alphab)/(trnModel.ndsum[u][m] + Kalphab);
			}
			
			// cumulate multinomial parameters
			for (int k = 1; k < trnModel.BK; k++){
				trnModel.pb[k] += trnModel.pb[k - 1];
			}
			
			// scaled sample because of unnormalized p[]
			double uk = Math.random() * trnModel.pb[trnModel.BK - 1];
			
			for (topic = 0; topic < trnModel.BK; topic++){
				if (trnModel.pb[topic] > uk) //sample topic w.r.t distribution p
					break;
			}
			if(topic==trnModel.BK)
				topic--;
			// add newly estimated z_i to count variables
			trnModel.nwb[w][topic] += 1;
			trnModel.ndb[u][m][topic] += 1;
			trnModel.nwsumb[topic] += 1;
			trnModel.ndsum[u][m] += 1;
			trnModel.ndca[u][m][2]+=1;
			
			topic=topic+trnModel.K+trnModel.CK;
			
		}
		
 		return topic;
	}
	
	//samping from candidate file...
	public int samplingf(int u, int m, int n){ 
		
		//N define the index number of the word in the document to the index of the local dataset in the whole corpus
		// remove z_i from the count variable
		int topic = trnModel.zf[u][m].get(n); //the index of the topic
		int w = trnModel.data.can_docs[u][m].words[n]; // word index in the global dataset
		
		double[] Vbeta = new double[trnModel.K];
		double[] Vbetac = new double[trnModel.CK];
		double asigma=3*sigma;
		double agamma=3*gamma;
		double Vbetab = trnModel.V * betab;
		double Kalpha = trnModel.K * alpha;
		double Kalphab = trnModel.BK * alphab;
		
		
		for(int i=0;i<trnModel.K;i++){
			Vbeta[i]=0.0;
			Vbeta[i]=trnModel.beta[i]*trnModel.V;
		}
		
		for(int i=0;i<trnModel.CK;i++){
			Vbetac[i]=0.0;
			Vbetac[i]=trnModel.betac[i]*trnModel.V;
		}
		
		//do multinominal sampling via cumulative method    	E step...
		double[] pe=new double[3];
		for(int c=0;c<3;c++){
			pe[c]=(trnModel.ndcaf[u][m][c]+sigma)/(trnModel.ndfsum[u][m]+asigma);
		}
		pe[1]=pe[1]+pe[0];
		pe[2]=pe[1]+pe[2];
		
		double ue=Math.random()*pe[2];
		
		int ee=2; //default: burst topic...
		if(ue<pe[0]){
			ee=0; //user topic...
		}else if(ue<pe[1]){
			ee=1;
		}else{
			ee=2;
		}
		
		if(ee==0){
			//for each user topic...
			
			for (int k = 0; k < trnModel.K; k++){
				trnModel.p[k]=0.0;
				double opt_beta=0.0;
				opt_beta=trnModel.beta[k]*trnModel.prePhi[k][w];
				trnModel.p[k] = ((trnModel.nw[w][k] + opt_beta)/(trnModel.nwsum[k] + Vbeta[k])) * (trnModel.ndf[u][m][k] + trnModel.alpha)/(trnModel.ndfsum[u][m] + Kalpha);
			}
			
			// cumulate multinomial parameters
			for (int k = 1; k < trnModel.K; k++){
				trnModel.p[k] += trnModel.p[k-1];
			}
			
			// scaled sample because of unnormalized p[]
	     	double uk = Math.random() * trnModel.p[trnModel.K - 1];
		 	
	     	for (topic = 0; topic < trnModel.K; topic++){
				if (trnModel.p[topic] > uk) //sample topic w.r.t distribution p
					break;
			}
			
	     	if(topic==trnModel.K)
				topic--;
	     	
			// add newly estimated z_i to count variables
			trnModel.nw[w][topic] += 1;
			trnModel.ndf[u][m][topic] += 1;
			trnModel.nwsum[topic] += 1;
			trnModel.ndfsum[u][m] += 1;
			trnModel.ndcaf[u][m][0]+=1;
	     	
		}else if(ee==1){
			
			//for common topic...
			
			for (int k = 0; k < trnModel.CK; k++){
				trnModel.pc[k]=0.0;
				double opt_beta=0.0;
				opt_beta=trnModel.betac[k]*trnModel.prePhic[k][w];
				trnModel.pc[k] = ((trnModel.nwc[w][k] + opt_beta)/(trnModel.nwsumc[k] + Vbetac[k])) * (trnModel.ndcf[u][m][k] + trnModel.alpha)/(trnModel.ndfsum[u][m] + Kalpha);
			}
			
			// cumulate multinomial parameters
			for (int k = 1; k < trnModel.CK; k++){
				trnModel.pc[k] += trnModel.pc[k-1];
			}
			
			// scaled sample because of unnormalized p[]
	     	double uk = Math.random() * trnModel.pc[trnModel.CK - 1];
		 	
	     	for (topic = 0; topic < trnModel.CK; topic++){
				if (trnModel.pc[topic] > uk) //sample topic w.r.t distribution p
					break;
			}
			
	     	if(topic==trnModel.CK)
				topic--;
	     	
			// add newly estimated z_i to count variables
			trnModel.nwc[w][topic] += 1;
			trnModel.ndcf[u][m][topic] += 1;
			trnModel.nwsumc[topic] += 1;
			trnModel.ndfsum[u][m] += 1;
			trnModel.ndcaf[u][m][1]+=1;
			
			topic =  topic+trnModel.K;
			
		}else{
			
			for (int k = 0; k < trnModel.BK; k++){
				trnModel.pb[k]=0.0;
				trnModel.pb[k] = (trnModel.nwb[w][k] + betab)/(trnModel.nwsumb[k] + Vbetab) * (trnModel.ndbf[u][m][k] + trnModel.alphab)/(trnModel.ndfsum[u][m] + Kalphab);
			}
			
			// cumulate multinomial parameters
			for (int k = 1; k < trnModel.BK; k++){
				trnModel.pb[k] += trnModel.pb[k - 1];
			}
			
			// scaled sample because of unnormalized p[]
			double uk = Math.random() * trnModel.pb[trnModel.BK - 1];
			
			for (topic = 0; topic < trnModel.BK; topic++){
				if (trnModel.pb[topic] > uk) //sample topic w.r.t distribution p
					break;
			}
			
			if(topic==trnModel.BK)
				topic--;
			
			// add newly estimated z_i to count variables
			trnModel.nwb[w][topic] += 1;
			trnModel.ndbf[u][m][topic] += 1;
			trnModel.nwsumb[topic] += 1;
			trnModel.ndfsum[u][m] += 1;
			trnModel.ndcaf[u][m][2]+=1;
			
			topic=topic+trnModel.K+trnModel.CK;
			
		}
		
 		return topic;
	}
	
	
	public void recAlphac(){
		
		//System.out.println("RECALPHA...");
		
		double[] Kalphac = new double[trnModel.U];
		for(int i=0;i<trnModel.U;i++){
			Kalphac[i]=0.0;
			for(int z=0;z<trnModel.CK;z++){
				Kalphac[i]+=trnModel.alphac[i][z];
			}
		}
		
		for(int u=0;u<trnModel.U;u++){
			
			double opt_a3=0.0;
			for(int i=0;i<trnModel.CK;i++){
				
				double opt_a1=0.0;
				double opt_a2=0.0;
				
				for(int j=0;j<trnModel.M[u];j++){
					opt_a1+=Math.abs(Num.digamma(Math.abs(trnModel.ndc[u][j][i]+trnModel.alphac[u][i]))-Num.digamma(Math.abs(trnModel.alphac[u][i]+0.1)));
					opt_a2+=Math.abs(Num.digamma(Math.abs(trnModel.ndsum[u][j]+ Kalphac[u]))-Num.digamma(Math.abs(Kalphac[u])));
				}
				
				trnModel.alphac[u][i]=trnModel.alphac[u][i]*opt_a1/opt_a2;
				opt_a3+=trnModel.preThetac[u][i];
			}
			//
			double Kalpha=0.0;
			
			for(int j=0;j<trnModel.CK;j++){
				Kalpha+=trnModel.alphac[u][j];
			}
			
			for(int j=0;j<trnModel.CK;j++){
				trnModel.alphac[u][j]=trnModel.alphac[u][j]/Kalpha;
			}
		}
		
	}
	
	public void recBeta(){
		
		//System.out.println("RECBETA...");
		double BET=0.0;
		
		for(int i=0;i<trnModel.K;i++){
		 
			double opt_b2=0.1;
			double opt_b1=0.1;
			//System.out.println(trnModel.beta[i]+trnModel.nwsum[i]);
			//System.out.println(trnModel.beta[i]);
			
			opt_b2+=Math.abs(Num.digamma(trnModel.beta[i]+trnModel.nwsum[i]+0.1)-Num.digamma(trnModel.beta[i]+0.1));
			
			//System.out.println("optb2 "+opt_b2);
			
			for(int w=0;w<trnModel.V;w++){
				double xxtmp=Math.abs(Num.digamma(trnModel.nw[w][i]+trnModel.beta[i]*trnModel.prePhi[i][w]+0.1)-Num.digamma(trnModel.beta[i]*trnModel.prePhi[i][w]+0.1));
				opt_b1+=(trnModel.prePhi[i][w]+0.1)*xxtmp; 
			}
				
			trnModel.beta[i]=trnModel.beta[i]*opt_b1/opt_b2;
			BET+=trnModel.beta[i];
		}
		
		for(int i=0;i<trnModel.K;i++){
			trnModel.beta[i]=trnModel.beta[i]/BET;
			//BigDecimal b = new BigDecimal(trnModel.beta[i]);
			//trnModel.beta[i]=b.setScale(7, BigDecimal.ROUND_HALF_UP).doubleValue();
		}
		
	}
	
	public void recBetac(){
		//System.out.println("RECBETAC...");
		
		double BET=0.0;
		
		for(int i=0;i<trnModel.CK;i++){
		 
			double opt_b2=0.1;
			double opt_b1=0.1;
			
			opt_b2+=Math.abs(Num.digamma(trnModel.betac[i]+trnModel.nwsumc[i]+0.1)-Num.digamma(trnModel.betac[i]+0.1));
			
			for(int w=0;w<trnModel.V;w++){
				double xxtmp=Math.abs(Num.digamma(trnModel.nwc[w][i]+trnModel.betac[i]*trnModel.prePhic[i][w]+0.1)-Num.digamma(trnModel.betac[i]*trnModel.prePhic[i][w]+0.1));
				opt_b1+=(trnModel.prePhic[i][w]+0.1)*xxtmp; 
			}
				
			trnModel.betac[i]=trnModel.betac[i]*opt_b1/opt_b2;
			BET+=trnModel.betac[i];
		}
		
		for(int i=0;i<trnModel.CK;i++){
			trnModel.betac[i]=trnModel.betac[i]/BET;
		}
	}
	
	//compute topic distributions.
	
	
	public void computeTheta(){
		//for user file...
		//for theta
		for(int u=0;u<trnModel.U;u++){
			for (int m = 0; m < trnModel.M[u]; m++){
				for (int k = 0; k < trnModel.K; k++){
					trnModel.theta[u][m][k] = (trnModel.nd[u][m][k] + trnModel.alpha*trnModel.preTheta[u][k]) / (trnModel.ndsum[u][m] + trnModel.K * alpha);
				}
			}
		}
		
		//for thetac
		for(int u=0;u<trnModel.U;u++){
			for (int m = 0; m < trnModel.M[u]; m++){
				for (int k = 0; k < trnModel.CK; k++){
					trnModel.thetac[u][m][k] = (trnModel.ndc[u][m][k] + trnModel.alphac[u][k]*trnModel.preThetac[u][k]) / (trnModel.ndsum[u][m] + Kalphac[u]);
				}
			}
		}
		
		//for thetab
		for(int u=0;u<trnModel.U;u++){
			for (int m = 0; m < trnModel.M[u]; m++){
				for (int k = 0; k < trnModel.BK; k++){
					trnModel.thetab[u][m][k] = (trnModel.ndb[u][m][k] + alphab) / (trnModel.ndsum[u][m] + trnModel.BK * alphab);
				}
			}
		}
		
		//for candidate file...
		//for thetaf
		for(int u=0;u<trnModel.U;u++){
			for (int m = 0; m < trnModel.MC[u]; m++){
				for (int k = 0; k < trnModel.K; k++){
					trnModel.thetaf[u][m][k] = (trnModel.ndf[u][m][k] + alpha) / (trnModel.ndfsum[u][m] + trnModel.K * alpha);
				}
			}
		}
		
		//for thetacf
		for(int u=0;u<trnModel.U;u++){
			for (int m = 0; m < trnModel.MC[u]; m++){
				for (int k = 0; k < trnModel.CK; k++){
					trnModel.thetacf[u][m][k] = (trnModel.ndcf[u][m][k] + alpha) / (trnModel.ndfsum[u][m] + trnModel.CK * alpha);
				}
			}
		}
		
		//for thetabf
		for(int u=0;u<trnModel.U;u++){
			for (int m = 0; m < trnModel.MC[u]; m++){
				for (int k = 0; k < trnModel.BK; k++){
					trnModel.thetabf[u][m][k] = (trnModel.ndbf[u][m][k] + alphab) / (trnModel.ndfsum[u][m] + trnModel.BK * alphab);
				}
			}
		}
		
	}
	
	
	public void computePhi(){
		//for phi
		for (int k = 0; k < trnModel.K; k++){
			
			for (int w = 0; w < trnModel.V; w++){
				trnModel.phi[k][w] = (trnModel.nw[w][k] + trnModel.beta[k]*trnModel.prePhi[k][w]+0.1) / (trnModel.nwsum[k] + Vbeta[k]+trnModel.K*0.1);
				//System.out.println(trnModel.phi[k][w]);
			}
		}
		//for phic
		for (int k = 0; k < trnModel.CK; k++){
			
			for (int w = 0; w < trnModel.V; w++){
				trnModel.phic[k][w] = (trnModel.nwc[w][k] + trnModel.betac[k]*trnModel.prePhic[k][w]+0.1) / (trnModel.nwsumc[k] + Vbetac[k]+trnModel.K*0.1);
			}
		}
		//for phib
		for (int k = 0; k < trnModel.BK; k++){
			for (int w = 0; w < trnModel.V; w++){
				trnModel.phib[k][w] = (trnModel.nwb[w][k] + betab) / (trnModel.nwsumb[k] + trnModel.V * betab);
			}
		}
	}
}
