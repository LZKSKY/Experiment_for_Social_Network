package cur;
import java.io.File;
import java.util.Vector;
import umontreal.iro.lecuyer.util.*;
public class OrgEstor {
	public OrgModel trnModel;
	public DynOption option;
	  
	public double beta=0.1;
	public double betab=0.1;
	public double alpha=0.0;
	public double alphab=0.0;
	public double sigma=0.3;
	public double gamma=0.3;
	
	public boolean init(DynOption option){
		this.option = option;
		trnModel = new OrgModel();
		trnModel.initNewModel(option);
		int numT=trnModel.K;	
		alpha=50.0/numT;
		alphab = 50.0/trnModel.BK;
		sigma=trnModel.sigma;
		gamma=trnModel.gamma;
		beta=trnModel.beta;
		betab=trnModel.betab;
		return true;
	}
	
	public void estimate(){

		int liter=0;

		for (liter = 0; liter < trnModel.niters; liter++){
			System.out.println("The"+liter+"th iteration....");
			
			for(int u=0;u<trnModel.U;u++){
				//step 1: for user file... 
				
				// for all z_i
				for (int m = 0; m < trnModel.M[u]; m++){				
					for (int n = 0; n < trnModel.data.docs[u][m].length; n++){
						
						// sample from p(z_i|z_-i, w)
						int topic = sampling(u, m, n);
						trnModel.z[u][m].set(n, topic);
					}// end for each word
				}// end for each document
				
				//step2: for candidate file...
				for (int m = 0; m < trnModel.MC[u]; m++){				
					for (int n = 0; n < trnModel.data.can_docs[u][m].length; n++){
						// sample from p(z_i|z_-i, w)
						int topic = samplingf(u, m, n);
						trnModel.zf[u][m].set(n, topic);
					}// end for each word
				}// end for each document
				
			}
			
		}// end iterations		
		
		
		System.out.println("Gibbs sampling completed!\n");
		System.out.println("Saving the final model!\n");
		
		computeTheta();
		computePhi();
		
		for(int u=0;u<trnModel.U;u++){
			trnModel.saveModel(u);
		}
		trnModel.saveModelPhi(trnModel.dir + "/model" + trnModel.phiSuffix);
		trnModel.saveModelPhib(trnModel.dir + "/model" + trnModel.phiSuffixc);
	}
	
	/**
	 * Do sampling
	 * @param m document number
	 * @param n word number
	 * @return topic id
	 */
	//sampling from user file...
	public int sampling(int u, int m, int n){ 
		//N define the index number of the word in the document to the index of the local dataset in the whole corpus
		// remove z_i from the count variable
		int topic = trnModel.z[u][m].get(n); //the index of the topic
		int w = trnModel.data.docs[u][m].words[n]; // word index in the global dataset
		
		double asigma=3*sigma;
		double agamma=3*gamma;
		double Vbeta = trnModel.V * beta;
		double Vbetab = trnModel.V * betab;
		double Kalpha = trnModel.K * alpha;
		double Kalphab = trnModel.BK * alphab;
		
		//sample e from user file...
		
		double[] pe=new double[2];
		for(int c=0;c<2;c++){
			pe[c]=(trnModel.ndca[u][m][c]+sigma)/(trnModel.ndsum[u][m]+asigma);
		}
		pe[1]=pe[1]+pe[0];
		double ue=Math.random()*pe[1];
		
		int ee=1; //default: burst topic...
		if(ue<pe[0]){
			ee=0; //user topic...
		}
		
		
		if(ee==0){
			//for user topic...
			
			for (int k = 0; k < trnModel.K; k++){
				trnModel.p[k]=0.0;
				trnModel.p[k] = (trnModel.nw[w][k] + beta)/(trnModel.nwsum[k] + Vbeta) * (trnModel.nd[u][m][k] + trnModel.alpha)/(trnModel.ndsum[u][m] + Kalpha);
				
			}
			
			// cumulate multinomial parameters
			for (int k = 1; k < trnModel.K; k++){
				trnModel.p[k]+=trnModel.p[k-1];
			}
			
			// scaled sample because of unnormalized p[]
			double uk = Math.random()*trnModel.p[trnModel.K-1];
			
			for (topic = 0; topic < trnModel.K; topic++){
				if (trnModel.p[topic] > uk) //sample topic w.r.t distribution p
					break;
			}
			// add newly estimated z_i to count variables
			trnModel.nw[w][topic]=trnModel.nw[w][topic]+1;
			trnModel.nd[u][m][topic]=trnModel.nd[u][m][topic]+1;
			trnModel.nwsum[topic]=trnModel.nwsum[topic]+1;
			trnModel.ndsum[u][m]=trnModel.ndsum[u][m]+1;
			trnModel.ndca[u][m][0]=trnModel.ndca[u][m][0]+1;
			
		}else{
			//for burst topic... 
			
			for (int k = 0; k < trnModel.BK; k++){
				trnModel.pb[k]=0.0;
				trnModel.pb[k] = (trnModel.nwb[w][k] + betab)/(trnModel.nwsumb[k] + Vbetab) * (trnModel.ndb[u][m][k] + trnModel.alphab)/(trnModel.ndsum[u][m] + Kalphab);
			}
			
			// cumulate multinomial parameters
			for (int k = 1; k < trnModel.BK; k++){
				trnModel.pb[k]+=trnModel.pb[k-1];
			}
			
			// scaled sample because of unnormalized p[]
			double uk = Math.random() * trnModel.pb[trnModel.BK-1];
			
			for (topic = 0; topic < trnModel.BK; topic++){
				if (trnModel.pb[topic] > uk) //sample topic w.r.t distribution p
					break;
			}
			
			// add newly estimated z_i to count variables
			trnModel.nwb[w][topic]++;
			trnModel.ndb[u][m][topic]++;
			trnModel.nwsumb[topic]++;
			trnModel.ndsum[u][m]++;
			trnModel.ndca[u][m][1]++;
			
			topic=topic+trnModel.K;
		}
		
 		return topic;
	}
	
	//samping from candidate file...
	public int samplingf(int u, int m, int n){ 
		//N define the index number of the word in the document to the index of the local dataset in the whole corpus
		// remove z_i from the count variable
		int topic = trnModel.zf[u][m].get(n); //the index of the topic
		int w = trnModel.data.can_docs[u][m].words[n]; // word index in the global dataset
				
		double asigma=3*sigma;
		double agamma=3*gamma;
		double Vbeta = trnModel.V * beta;
		double Vbetab = trnModel.V * betab;
		double Kalpha = trnModel.K * alpha;
		double Kalphab = trnModel.BK * alphab;
				
		//sample e from candidate file...
				
		double[] pe=new double[2];
		for(int c=0;c<2;c++){
			pe[c]=(trnModel.ndcaf[u][m][c]+sigma)/(trnModel.ndfsum[u][m]+asigma);
		}
		pe[1]=pe[1]+pe[0];
		double ue=Math.random()*pe[1];
				
		int ee=1; //default: burst topic...
		if(ue>pe[0]){
			ee=0; //user topic...
		}
				
		if(ee==0){
			//for user topic...	
			for (int k = 0; k < trnModel.K; k++){
				trnModel.p[k]=0.0;
				trnModel.p[k] = (trnModel.nw[w][k] + beta)/(trnModel.nwsum[k] + Vbeta) * (trnModel.ndf[u][m][k] + trnModel.alpha)/(trnModel.ndfsum[u][m] + Kalpha);
			}
					
			// cumulate multinomial parameters
			for (int k = 1; k < trnModel.K; k++){
				trnModel.p[k] += trnModel.p[k - 1];
			}
					
			// scaled sample because of unnormalized p[]
			double uk = Math.random() * trnModel.p[trnModel.K - 1];
			for (topic = 0; topic < trnModel.K; topic++){
				if (trnModel.p[topic] > uk) //sample topic w.r.t distribution p
					break;
			}
					
					// add newly estimated z_i to count variables
			trnModel.nw[w][topic]++;
			trnModel.ndf[u][m][topic]++;
			trnModel.nwsum[topic]++;
			trnModel.ndfsum[u][m]++;
			trnModel.ndcaf[u][m][0]++;
					
		}else{
		//for burst topic... 
					
			for (int k = 0; k < trnModel.BK; k++){
				trnModel.pb[k]=0.0;
				trnModel.pb[k] = (trnModel.nwb[w][k] + betab)/(trnModel.nwsumb[k] + Vbetab) * (trnModel.ndbf[u][m][k] + trnModel.alphab)/(trnModel.ndfsum[u][m] + Kalphab);
			}
					
			// cumulate multinomial parameters
			for (int k = 1; k < trnModel.BK; k++){
				trnModel.pb[k] += trnModel.pb[k - 1];
			}
					
			// scaled sample because of unnormalized p[]
			double uk = Math.random() * trnModel.pb[trnModel.BK - 1];
			for (topic = 0; topic < trnModel.BK; topic++){
				if (trnModel.pb[topic] > uk) //sample topic w.r.t distribution p
					break;
			}
					
			// add newly estimated z_i to count variables
			trnModel.nwb[w][topic]++;
			trnModel.ndbf[u][m][topic]++;
			trnModel.nwsumb[topic]++;
			trnModel.ndfsum[u][m]++;
			trnModel.ndcaf[u][m][1]++;
			topic=topic+trnModel.K;
		}
				
		return topic;
	}
	
	
	public void computeTheta(){
		//for user file...
		//for theta
		for(int u=0;u<trnModel.U;u++){
			for (int m = 0; m < trnModel.M[u]; m++){
				for (int k = 0; k < trnModel.K; k++){
					trnModel.theta[u][m][k] = (trnModel.nd[u][m][k] + alpha) / (trnModel.ndsum[u][m] + trnModel.K * alpha);
				}
			}
		}
		//for thetab
		for(int u=0;u<trnModel.U;u++){
			for (int m = 0; m < trnModel.M[u]; m++){
				for (int k = 0; k < trnModel.BK; k++){
					trnModel.thetab[u][m][k] = (trnModel.ndb[u][m][k] + alphab) / (trnModel.ndsum[u][m] + trnModel.BK * alphab);
				}
			}
		}
		
		//for candidate file...
		//for thetaf
		for(int u=0;u<trnModel.U;u++){
			for (int m = 0; m < trnModel.MC[u]; m++){
				for (int k = 0; k < trnModel.K; k++){
					trnModel.thetaf[u][m][k] = (trnModel.ndf[u][m][k] + alpha) / (trnModel.ndfsum[u][m] + trnModel.K * alpha);
				}
			}
		}
		//for thetabf
		for(int u=0;u<trnModel.U;u++){
			for (int m = 0; m < trnModel.MC[u]; m++){
				for (int k = 0; k < trnModel.BK; k++){
					trnModel.thetabf[u][m][k] = (trnModel.ndbf[u][m][k] + alphab) / (trnModel.ndfsum[u][m] + trnModel.BK * alphab);
				}
			}
		}
	}
	
	
	public void computePhi(){
		//for phi
		for (int k = 0; k < trnModel.K; k++){
			for (int w = 0; w < trnModel.V; w++){
				trnModel.phi[k][w] = (trnModel.nw[w][k] + beta) / (trnModel.nwsum[k] + trnModel.V * beta);
				//System.out.println(trnModel.nw[w][k]+"-->"+w+":"+k);
				//System.out.println(trnModel.nwsum[k]+"-->"+k);
			}
		}
		//for phib
		for (int k = 0; k < trnModel.BK; k++){
			for (int w = 0; w < trnModel.V; w++){
				trnModel.phib[k][w] = (trnModel.nwb[w][k] + betab) / (trnModel.nwsumb[k] + trnModel.V * betab);
			}
		}
	}
	
	
}
