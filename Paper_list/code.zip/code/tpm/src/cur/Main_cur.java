package cur;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

import beg.EstWords;
  
public class Main_cur {

	public static String INPUTPATH_lda = "/Users/zhaochunren/ExperimentData/";
	public static int NumOfTop=100;
	public static String OUTPUTDIR = "/Users/zhaochunren/ExperimentData/";

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BufferedReader reader;
		File filePath = new File(INPUTPATH_lda);
		
		//int NumOfTop = 50;
		try {
			
						String path_threads = filePath.getPath();
						String[] xx = new String[2];
						xx[0] = path_threads;
						xx[1] = "globe_forLda.txt";
						
						
						// global statistical
						
						EstWords global_est = new EstWords();
						global_est.init(xx);
	                    
						
						
						// begin the slices
						reader = new BufferedReader(new FileReader(path_threads
								+ "/sta.txt"));
						int uPBoClu = Integer.parseInt(reader.readLine());
						reader.close();
	                    
						//begin the original...
						
						String tmp="-est "
							+ "-relSlices "+ 0+" "
							+ "-org 0 "
							+ "-ntopics "+ NumOfTop+ " "
							+ "-niters 2000 -savestep 2000 -twords 20 ";
						
						//File ddd=new File(path_threads+"\\"+NumOfTop);
						//if(!ddd.exists()){
							//ddd.mkdirs();
						//}
						
						
						
						//String path_ddd=ddd.getPath();
						//System.out.println(path_ddd);
						
						
						
						tmp+= "-dir " + path_threads + " ";
						tmp+= "-dfile " + 0 + ".txt ";
						tmp += "-globalDicFile " + path_threads
						+ "/global/wordmap.txt ";
						
						//System.out.println(tmp);
						String[] lda_tmp = tmp.split(" ");
						Process.main(lda_tmp);
						
						if (uPBoClu >= 1) {
							// begin the slice iteration...
							for (int c = 1; c <= uPBoClu; c++) {
	                            
								//System.out.println(c+"CCCC");
								
								String temp = "-est "
										+ "-relSlices "+ c+" "
										+ "-org 1 "
										+ "-ntopics "+ NumOfTop+" "
										+ "-niters 2000 -savestep 2000 -twords 20 ";

								temp += "-dir " + path_threads + " ";
								temp += "-dfile " + c + ".txt ";
								temp += "-globalDicFile " + path_threads
										+ "/global/wordmap.txt ";

								
								//System.out.println(temp);
								
								String[] lda_temp = temp.split(" ");
								Process.main(lda_temp);
							}
							// end the iteration...
						}
					
				
		} catch (Exception e) {
			System.out.println(e.getLocalizedMessage());
		}

	}

}
