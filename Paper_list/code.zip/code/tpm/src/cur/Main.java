package cur;

import java.io.*;
import java.math.BigDecimal;
import java.util.Vector;
import org.kohsuke.args4j.*;

import beg.*;
import pub.*;

public class Main {
	
	public static String INPUTPATH_lda = "/Users/zhaochunren/dataset/example_sigir13";
	public static int NumOfTop = 20;
	public static int NumOfCTop= 20;
	public static int NumOfBTop= 20;
	public static double alpha=0.5;
	public static double beta = 0.1;
	/**
	 * @param args
	 * copyright by 
	 * Zhaochun ren
	 * uva
	 * 
	 */
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BufferedReader reader;
		BufferedWriter writer;
		File filePath = new File(INPUTPATH_lda);
		try {
				
			
			String path_threads = filePath.getPath();
				
			String[] xx = new String[2];
			xx[0] = path_threads;
			xx[1] = "globe_forLda.txt";
			
			// begin the slices
			reader = new BufferedReader(new FileReader(path_threads+ "/sta.txt"));
			int uPBoClu = Integer.parseInt(reader.readLine());
			int nouser = Integer.parseInt(reader.readLine());
			int nocircles=Integer.parseInt(reader.readLine());
			reader.close();	
			// global statistical
			EstWords global_est = new EstWords();
			global_est.init(xx);
			
			//suppose you already have a file containing social circles information...
			//read each user's social circle no.
			int[][] ucircle=new int[nouser][];
			reader = new BufferedReader(new FileReader(path_threads+ "/social.txt"));
			for(int i=0;i<nouser;i++){
				String[] us=reader.readLine().split(" ");
				int[] lin=new int[us.length];
				for(int j=0;j<us.length;j++){
					lin[j]=Integer.parseInt(us[j]);
				}
				ucircle[i]=lin;
			}
			reader.close();
			
			//read each social circle information
			int[][] scircle=new int[nocircles][];
			reader = new BufferedReader(new FileReader(path_threads+ "/circle.txt"));
			for(int i=0;i<nocircles;i++){
				String[] us=reader.readLine().split(" ");
				int[] lin=new int[us.length];
				for(int j=0;j<us.length;j++){
					lin[j]=Integer.parseInt(us[j]);
				}
				scircle[i]=lin;
			}
			reader.close();
			
			DynOption option = new DynOption();
			CmdLineParser parser = new CmdLineParser(option);
			
			//run start, from t0
			//at each time slice, there are U users folder under each "time" folder
			//in each user folder, there are two input files from the user and candidate documents
                
			//begin the original t0 slice...
			File path_t0=new File(path_threads+"/0");
			if(path_t0.isDirectory()){
			//here in each user's folder, there is a file for user's own tweets and another file for candidate tweets
				String tmp="-relSlices "+ 0+" "
					+ "-org 0 "
					+ "-nusers " + nouser+ " "
					+ "-ntopics "+ NumOfTop+ " "
					+ "-nbtopics "+ NumOfBTop+" "
					+ "-niters 2000 ";
							
				tmp+= "-dir " + path_threads+"/0" + " ";
				tmp += "-globalDicFile " + path_threads+ "/global/wordmap.txt ";
				
				String[] lda_tmp = tmp.split(" ");
				parser.parseArgument(lda_tmp);
				
				OrgEstor estimator=new OrgEstor();
				estimator.init(option);
				estimator.estimate();
				NumOfCTop=NumOfBTop;
			}
			
			//combine theta_com from each user's friends...
			for(int u=0;u<nouser;u++){
				double[] thetabk=new double[NumOfBTop];
				int[] sids=ucircle[u];
				double[] weights=new double[sids.length];
				for(int j=0;j<sids.length;j++){
					weights[j]=(1.0)/sids.length;
				}
				
				for(int j=0;j<sids.length;j++){
					double[] temp_sumthetak=new double[NumOfBTop];
					int[] uus=scircle[sids[j]];
					if(uus.length>1){
						for(int p=0;p<uus.length;p++){
							int uid=uus[p];
							double[] thetacu=new double[NumOfBTop];
							
							reader = new BufferedReader(new FileReader(path_threads+"/0/"+ uid+".thetab"));
							String[] lll=reader.readLine().split(" ");
							for(int te=0;te<NumOfBTop;te++){
								String ite=lll[te];
								thetacu[te]=Double.parseDouble(ite);
							}
							reader.close();
							
							for(int z=0;z<NumOfBTop;z++){
								temp_sumthetak[z]+=thetacu[z];
							}
							
						}
						for(int z=0;z<NumOfBTop;z++){
							temp_sumthetak[z]=temp_sumthetak[z]/uus.length;
						}
					}
					
					for(int z=0;z<NumOfBTop;z++){
						thetabk[z]+=temp_sumthetak[z]*weights[j];
					}
				}
				
				for(int z=0;z<NumOfBTop;z++){
					thetabk[z]=thetabk[z]*alpha;
				}
				
				reader = new BufferedReader(new FileReader(path_threads+"/0/"+ u+".thetab"));
				String[] lll=reader.readLine().split(" ");
				for(int te=0;te<NumOfBTop;te++){
					String ite=lll[te];
					thetabk[te]+=Double.parseDouble(ite)*(1-alpha);
				}
				reader.close();
				
				writer = new BufferedWriter(new FileWriter((path_threads+"/0/"+u+".thetax")));
				for(int z=0;z<NumOfBTop;z++){
					BigDecimal b = new BigDecimal(thetabk[z]);  
					thetabk[z]=b.setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
					writer.write(thetabk[z] + " ");
				}
				writer.write("\n");
				writer.close();
			}
			
			//start from slice 1 to T...
			if (uPBoClu >= 1) {
				// begin the slice iteration...
				for (int c = 1; c <= uPBoClu; c++) {
                //... 
				
				String temp ="-relSlices "+ c+" "
						+ "-org 1 "
						+ "-nusers " + nouser+ " "
						+ "-ntopics "+ NumOfTop+" "
						+ "-nctopics "+ NumOfCTop +" "
						+ "-nbtopics "+ NumOfBTop+" "
						+ "-predir "+ path_threads + " "
						+ "-niters 2000 ";

				 temp += "-dir " + path_threads+"/"+c + " ";
				 temp += "-globalDicFile " + path_threads+ "/global/wordmap.txt ";
						
				 String[] lda_temp = temp.split(" ");
				
				 option = new DynOption();
				 parser = new CmdLineParser(option);
				 parser.parseArgument(lda_temp);
				
				 SliEstor estimator2 = new SliEstor();
				 estimator2.init(option);
				 estimator2.estimate();	
				 
				//save theta to update each user u's x(t-1)--> thetax file
				
				 for(int u=0;u<nouser;u++){
					 	
						double[] thetabk=new double[NumOfCTop+NumOfBTop];
						
						int[] sids=ucircle[u];
						double[] weights=new double[sids.length];
						for(int j=0;j<sids.length;j++){
							weights[j]=(1.0)/sids.length;
						}
						
						for(int j=0;j<sids.length;j++){
							double[] temp_sumthetak=new double[NumOfBTop+NumOfCTop];
							int[] uus=scircle[sids[j]];
							if(uus.length>1){
								for(int p=0;p<uus.length;p++){
									int uid=uus[p];
									double[] thetacu=new double[NumOfBTop+NumOfCTop];
									
									reader = new BufferedReader(new FileReader(path_threads+"/"+c+"/"+ uid+".thetab"));
									String[] lll=reader.readLine().split(" ");
									int not=NumOfBTop+NumOfCTop;
									
									for(int te=0;te<not;te++){
										String ite=lll[te];
										thetacu[te]=Double.parseDouble(ite);
									}
									reader.close();
									
									for(int z=0;z<not;z++){
										temp_sumthetak[z]+=thetacu[z];
									}
									
								}
								for(int z=0;z<(NumOfBTop+NumOfCTop);z++){
									temp_sumthetak[z]=temp_sumthetak[z]/uus.length;
								}
							}
							
							for(int z=0;z<(NumOfBTop+NumOfCTop);z++){
								thetabk[z]+=temp_sumthetak[z]*weights[j];
							}
						}
						
						for(int z=0;z<(NumOfBTop+NumOfCTop);z++){
							thetabk[z]=thetabk[z]*alpha;
						}
						
						reader = new BufferedReader(new FileReader(path_threads+"/"+c+"/"+ u+".thetab"));
						String[] lll=reader.readLine().split(" ");
						for(int te=0;te<(NumOfBTop+NumOfCTop);te++){
							String ite=lll[te];
							thetabk[te]+=Double.parseDouble(ite)*(1-alpha);
						}
						reader.close();
						
						writer = new BufferedWriter(new FileWriter((path_threads+"/"+c+"/"+u+".thetax")));
						for(int z=0;z<(NumOfBTop+NumOfCTop);z++){
							BigDecimal b = new BigDecimal(thetabk[z]);  
							thetabk[z]=b.setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
							writer.write(thetabk[z] + " ");
						}
						writer.write("\n");
						writer.close();
					}
				 	
				 	NumOfCTop+=NumOfBTop;
				 	System.out.println(NumOfCTop);
				}
				
				
				// end the iteration...
		    }

		} catch (Exception e) {
			System.out.println(e.getLocalizedMessage());
		}

	}

}
