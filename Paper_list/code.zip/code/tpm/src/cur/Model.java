/*
 * Copyright (C) 2007 by
 * 
 * 	Xuan-Hieu Phan
 *	hieuxuan@ecei.tohoku.ac.jp or pxhieu@gmail.com
 * 	Graduate School of Information Sciences
 * 	Tohoku University
 * 
 *  Cam-Tu Nguyen
 *  ncamtu@gmail.com
 *  College of Technology
 *  Vietnam National University, Hanoi
 *
 * JGibbsLDA is a free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published
 * by the Free Software Foundation; either version 2 of the License,
 * or (at your option) any later version.
 *
 * JGibbsLDA is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with JGibbsLDA; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA.
 */
package cur;
 
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.StringTokenizer;
import java.util.Vector;
import pub.*;
public class Model {	
	
	//--------------------------------------------------------------
	
	public static String thetaSuffix;		//suffix for theta (topic - document distribution) file
	public static String thetaSuffixb;		//suffix for thetab (common topic - document distribution) file
	public static String thetaSuffixf;		//suffix for thetaf (topic - candidate document distribution) file
	public static String thetaSuffixbf;		//suffix for thetabf (common topic - candiate document distribution) file
	public static String phiSuffix;		//suffix for phi file (topic - word distribution) file
	public static String phiSuffixb; //suffix for phib file (common topic - word distribution) file
	
	//---------------------------------------------------------------
	//	Model Parameters and Variables
	//---------------------------------------------------------------
	
	public String prephiFile;
	public String prephicFile;
	
//	public String[] prethetaUfile;   //size U ..user topics file
//	public String[] prethetaXfile;  //size U..common topics file
	
	LocalDataset data;
	
	public String wordMapFile; 		//file that contain word to id map
	public String globalDicFile;
	public String dir;
	public String predir;
	public int U;
	public int relSlices; //related slices...
	
	//LDA  hyperparameters
	public double[][] alphac; //size: U*CK
	public double[] beta;  //size: K
	public double[] betac; //size: CK
	
	public double alpha;
	public double alphab;
	public double betab;
	public double gamma; //dirichlet prior for user-topic category
	public double sigma; //dirichlet prior for can-topic category
	
	public double[][] preTheta; //size: U*K
	public double[][] preThetac; //size: U*CK
	public double[][] prePhi; //size: K*V
	public double[][] prePhic; //size: CK*V
	
	public int[] M; //dataset size (i.e., number of docs for each user)
	public int[] MC; //dataset candidate size (number of candidate docs for each user)
	public int V; //vocabulary size
	public int K; //number of topics
	public int CK; //number of common topics
	public int BK; //number of burst topics
	
	public int niters; //number of Gibbs sampling iteration
	
	// Estimated/Inferenced parameters
	public double [][][] theta; //theta: document - topic distributions, size U x M x K
	public double [][][] thetac; //size U x M x CK
	public double [][][] thetab; //thetab: document - burst topic distributions, size U x M x BK
	public double [][] phi; // phi: topic-word distributions, size K x V
	public double [][] phic; //CK x V
	public double [][] phib; //phib: burst topic-word distributions, size  BK x V
	public double [][][] thetaf; //theta: candidate document - topic distributions, size U x M x K
	public double [][][] thetacf; //size U x M x CK
	public double [][][] thetabf; //thetab: candiate document - burst topic distributions, size U x M x BK
	
	
	// Temp variables while sampling
	public Vector<Integer> [][] z; //topic assignments for words, size U x M x doc.size() {K+CK+BK}
	public Vector<Integer> [][] zf; //topic assignments for words, size U x MC x doc.size() {K+CK+BK}
	
	//private
	protected int [][] nw; //nw[i][j]: number of instances of word/term i assigned to topic j, size V x K
	protected int [][] nwb; //nwb[i][j]: number of instances of word/term i assigned to topic j, size V x BK
	protected int [][] nwc; //nwc[i][j]: number of instances of word/term i assigned to common topics, size V x CK
	
	protected int [][][] nd; //nd[i][j]: number of words in document i assigned to topic j, size U x M x K
	protected int [][][] ndf; //nd[i][j]: number of words in document i (candiate files) assigned to topic j, size U x MC x K
	protected int [][][] ndb; //ndb[i][j]: number of words in document i assigned to topic j, size U x M x BK
	protected int [][][] ndbf; //ndbf[i][j]: number of words in document i (candiate files) assigned to topic j, size U x MC x BK
	protected int [][][] ndc; //size U x M x CK
	protected int [][][] ndcf; //U x MC x CK
	
	protected int [][] nwca; //nwb[i][j]: number of instances of words i assigned to topic category, size V x 3 
	protected int [][][] ndca; //ndca[i][j]: number of words in document i assigned to category j, size U x M x 3
	protected int [][][] ndcaf;//ndcaf[i][j]: number of words in candidate document i assigned to category j, size U x MCx 3
	
	protected int [] nwsum; //nwsum[j]: total number of words assigned to topic j, size K
	protected int [] nwsumc; //size CK
	protected int [] nwsumb; //nwsumb[j]: total number of words assigned to topic j, size BK
	protected int [][] ndsum; //ndsum[i]: total number of words in document i, size U x M
	protected int [][] ndfsum; //ndsum[i]: total number of words in candidate document i, size U x MC
	
	// temp variables for sampling
	protected double [] p;
	protected double [] pc;
	protected double [] pb;
	
	//---------------------------------------------------------------
	//	Constructors
	//---------------------------------------------------------------	

	public Model(){
		setDefaultValues();	
	}
	
	/**
	 * Set default values for variables
	 */
	public void setDefaultValues(){
		wordMapFile = "wordmap.txt";
		thetaSuffix = ".theta";
		thetaSuffixf = ".thetaf";
		thetaSuffixb = ".thetab";
		thetaSuffixbf = ".thetabf";
		phiSuffix = ".phi";
		phiSuffixb = ".phic";
		
		dir = "./";
		predir ="./";
		data =null;
		M = null;
		MC = null;
		U=0;
		V = 0;
		K = 100;
		CK = 100;
		BK =100;
		alphac =null;
		betac = null;
		beta= null;
		
		alpha=50.0/K;
		alphab =50.0/BK;
		betab=0.1;
		sigma=0.3;
		gamma=0.3;
		
		preTheta = null;
		preThetac = null;
		prePhi = null;
		prePhic = null;
		
		niters = 2000;
		
		z = null;
		zf = null;
		
		nw = null;
		nd = null;
		ndf = null;
		nwb = null;
		nwc = null;
		ndb = null;
		ndc = null;
		ndcf = null;
		ndbf = null;
		
		nwca =null;
		ndca =null;
		ndcaf=null;
		
		nwsum = null;
		nwsumb = null;
		nwsumc = null;
		ndsum = null;
		ndfsum = null;
		
		theta = null;
		thetab = null;
		thetaf = null;
		thetabf = null;
		
		phi = null;
		phib = null;
		
	}
	
	//---------------------------------------------------------------
	//	I/O Methods
	//---------------------------------------------------------------
	
	public boolean readPrePhi(String filename){
		
		try{
		
			BufferedReader reader=new BufferedReader(new InputStreamReader(new FileInputStream(filename), "UTF-8"));
			String line=reader.readLine();
			
			double[][] prephi_tmp=new double[K][V];
			for(int i=0;i<K;i++){
				String[] words_phi=line.split(" ");
				for(int j=0;j<V;j++){
					prephi_tmp[i][j]=Double.parseDouble(words_phi[j]);
				}
				line=reader.readLine();
			}
			reader.close();	
			prePhi=prephi_tmp;
			
		}catch(Exception e){
			System.out.println("Error while reading word-topic pre:" + e.getMessage());
			e.printStackTrace();
			return false;
		}
		return true;
	}

	public boolean readPrePhic(String filename){
		
		try{
		
			BufferedReader reader=new BufferedReader(new InputStreamReader(new FileInputStream(filename), "UTF-8"));
			String line=reader.readLine();
			double[][] prephi_tmp=new double[CK][V];
			for(int i=0;i<CK;i++){
				String[] words_phi=line.split(" ");
				for(int j=0;j<V;j++){
					prephi_tmp[i][j]=Double.parseDouble(words_phi[j]);
				}
				line=reader.readLine();
			}
			reader.close();	
			prePhic=prephi_tmp;
			
		}catch(Exception e){
			System.out.println("Error while reading word-topic pre:" + e.getMessage());
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public boolean readPreTheta(String dir){
		
		try{
			preTheta=new double[U][K];
			for(int u=0;u<U;u++){
				
				BufferedReader reader=new BufferedReader(new InputStreamReader(new FileInputStream(dir+"/"+u+".theta"), "UTF-8"));
				String line=reader.readLine();
				String[] words_theta=line.split(" ");
				for(int j=0;j<K;j++){
					preTheta[u][j]=Double.parseDouble(words_theta[j]);
				}
				reader.close();	
			}
			
		}catch(Exception e){
			System.out.println("Error while reading word-topic pre:" + e.getMessage());
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public boolean readPreThetax(String dir){
		
		try{
			preThetac=new double[U][CK];
			for(int u=0;u<U;u++){
				
				BufferedReader reader=new BufferedReader(new InputStreamReader(new FileInputStream(dir+"/"+u+".thetax"), "UTF-8"));
				String line=reader.readLine();
				String[] words_theta=line.split(" ");
				for(int j=0;j<CK;j++){
					preThetac[u][j]=Double.parseDouble(words_theta[j]);
				}
				reader.close();	
			}
			
		}catch(Exception e){
			System.out.println("Error while reading word-topic pre:" + e.getMessage());
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
		
	/**
	* Save theta (topic distribution) for this model
	*/
	
	public boolean saveModelTheta(String filename,int udx){
			try{
				BufferedWriter writer = new BufferedWriter(new FileWriter(filename));
					for (int j = 0; j < K; j++){
						double thetasum=0.0;
						for (int i = 0; i < M[udx]; i++){
							thetasum+=theta[udx][i][j];
						}
						
						BigDecimal b = new BigDecimal(thetasum);  
						thetasum=b.setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
						writer.write(thetasum + " ");
					}
				writer.write("\n");
				writer.close();
			}
			catch (Exception e){
				System.out.println("Error while saving topic distribution file for this model: " + e.getMessage());
				e.printStackTrace();
				return false;
			}
			return true;
	}
		
	/**
	* Save thetab (common topic distribution) for this model
	*/
	public boolean saveModelThetab(String filename, int udx){
		try{
			BufferedWriter writer = new BufferedWriter(new FileWriter(filename));
			//for common topics...
			for (int j = 0; j < CK; j++){
				double thetasum=0.0;
				for (int i = 0; i < M[udx]; i++){
					thetasum+=thetac[udx][i][j];
				}
				BigDecimal b = new BigDecimal(thetasum);  
				thetasum=b.setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
				writer.write(thetasum + " ");
			}
			//for burst topics...
			for (int j = 0; j < BK; j++){
				double thetasum=0.0;
				for (int i = 0; i < M[udx]; i++){
					thetasum+=thetab[udx][i][j];
				}
				BigDecimal b = new BigDecimal(thetasum);  
				thetasum=b.setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
				writer.write(thetasum + " ");
			}
			writer.write("\n");
			writer.close();
			}
			catch (Exception e){
				System.out.println("Error while saving topic distribution file for this model: " + e.getMessage());
				e.printStackTrace();
				return false;
			}
			return true;
		}
		
		/**
		* Save thetaf (topic-candidate doc distribution) for this model
		*/
	
		public boolean saveModelThetaf(String filename,int udx){
			try{
				BufferedWriter writer = new BufferedWriter(new FileWriter(filename));
				for (int i = 0; i < MC[udx]; i++){
					for (int j = 0; j < K; j++){
						writer.write(thetaf[udx][i][j] + " ");
					}
					writer.write("\n");
				}
				writer.close();
			}
			catch (Exception e){
				System.out.println("Error while saving topic distribution file for this model: " + e.getMessage());
				e.printStackTrace();
				return false;
			}
			return true;
		}
		
		
		
		/**
		 * Save thetabf (common topic-candiate doc distribution) for this model
		 */
		public boolean saveModelThetabf(String filename,int udx){
			try{
				BufferedWriter writer = new BufferedWriter(new FileWriter(filename));
				for (int i = 0; i < MC[udx]; i++){
					
					for (int j = 0; j < CK; j++){
						writer.write(thetacf[udx][i][j] + " ");
					}
					
					for (int j = 0; j < BK; j++){
						writer.write(thetabf[udx][i][j] + " ");
					}
					
					writer.write("\n");
				}
				writer.close();
			}
			catch (Exception e){
				System.out.println("Error while saving topic distribution file for this model: " + e.getMessage());
				e.printStackTrace();
				return false;
			}
			return true;
		}
		
			
		/**
		 * Save word-topic distribution
		 */
		
		public boolean saveModelPhi(String filename){
			try {
				
				double[] phis=new double[K];
				for (int i = 0; i < K; i++){
					for (int j = 0; j < V; j++){					
						phis[i]+=phi[i][j];
					}
					
				}
				
				BufferedWriter writer = new BufferedWriter(new FileWriter(filename));
				
				for (int i = 0; i < K; i++){
					for (int j = 0; j < V; j++){
						//System.out.println(phis[i]);
						phi[i][j]=phi[i][j]/phis[i];
						BigDecimal b = new BigDecimal(phi[i][j]);
						phi[i][j]=b.setScale(5, BigDecimal.ROUND_HALF_UP).doubleValue();
						writer.write(phi[i][j] + " ");
					}
					writer.write("\n");
				}
				writer.close();
			}
			catch (Exception e){
				System.out.println("Error while saving word-topic distribution:" + e.getMessage());
				e.printStackTrace();
				return false;
			}
			return true;
		}
		
		/**
		 * Save word-common topic distribution
		 */
		
		public boolean saveModelPhib(String filename){
			
			try {
				double[] phisc=new double[CK];
				for (int i = 0; i < CK; i++){
					for (int j = 0; j < V; j++){					
						phisc[i]+=phic[i][j];
					}
				}
				
				double[] phis=new double[BK];
				for (int i = 0; i < BK; i++){
					for (int j = 0; j < V; j++){					
						phis[i]+=phib[i][j];
					}
				}
				
				BufferedWriter writer = new BufferedWriter(new FileWriter(filename));
				
				for (int i = 0; i < CK; i++){
					for (int j = 0; j < V; j++){
						phic[i][j]=phic[i][j]/phisc[i];
						BigDecimal b = new BigDecimal(phic[i][j]);
						phic[i][j]=b.setScale(5, BigDecimal.ROUND_HALF_UP).doubleValue();
						writer.write(phic[i][j] + " ");
					}
					writer.write("\n");
				}
				
				for (int i = 0; i < BK; i++){
					for (int j = 0; j < V; j++){
						phib[i][j]=phib[i][j]/phis[i];
						BigDecimal b = new BigDecimal(phib[i][j]);
						phib[i][j]=b.setScale(5, BigDecimal.ROUND_HALF_UP).doubleValue();
						writer.write(phib[i][j] + " ");
					}
					writer.write("\n");
				}
				writer.close();
			}
			catch (Exception e){
				System.out.println("Error while saving word-topic distribution:" + e.getMessage());
				e.printStackTrace();
				return false;
			}
			return true;
		}
		
		
		/**
		 * Save other information of this model for each user... filename should be considered user's id... see saveModel method...
		 */
		
		public boolean saveModelOthers(int udx){
			try{
				//alphac, beta, betac
				BufferedWriter writer = new BufferedWriter(new FileWriter(dir + "/" + udx + ".others"));
				for(int i=0;i<alphac[udx].length;i++){
					writer.write(alphac[udx][i]+" ");
				}
				writer.write("\n");
				for(int i=0;i<K;i++){
					writer.write(beta[i]+" ");
				}
				writer.write("\n");
				for(int i=0;i<CK;i++){
					writer.write(betac[i]+" ");
				}
				writer.write("\n");
				writer.close();
			}
			catch(Exception e){
				System.out.println("Error while saving model others:" + e.getMessage());
				e.printStackTrace();
				return false;
			}
			return true;
		}
		
		/**
		* Save model
		*/
		public void saveModel(int udx){
			saveModelOthers(udx);
			saveModelTheta(dir + "/" + udx + thetaSuffix, udx);
			saveModelThetab(dir + "/" + udx + thetaSuffixb, udx);
			saveModelThetaf(dir + "/" + udx + thetaSuffixf, udx);
			saveModelThetabf(dir + "/" + udx + thetaSuffixbf, udx);
		}
		
		
		//---------------------------------------------------------------
		//	Init Methods
		//---------------------------------------------------------------
		/**
		 * initialize the model
		 */
		protected boolean init(DynOption option){		
			
			K = option.K;
			CK = option.CK;
			BK = option.BK;
			U=option.nuser;
			relSlices=option.relSlices;
			
			alpha=50.0/K;
			alphab=50.0/BK;
			betab=0.1;
			gamma=0.33;
			sigma=0.33;
			
			alphac =new double[U][CK];
			beta = new double[K];
			betac = new double[CK];
			
			for(int u=0;u<U;u++){
				for(int z=0;z<CK;z++){
					alphac[u][z]=0.5;
				}
			}
			
			for(int z=0;z<K;z++){
				beta[z]=0.5;
			}
			for(int z=0;z<CK;z++){
				betac[z]=0.5;
			}
			
			niters = option.niters;
			dir = option.dir;
			predir=option.predir;
			
			if (dir.endsWith("/"))
				dir = dir.substring(0, dir.length() - 1);
			
			if (predir.endsWith("/"))
				predir = predir.substring(0, predir.length() - 1);
			
			
			int prrel=relSlices-1;
			prephiFile=predir+"/"+prrel+"/model.phi";
			prephicFile = predir+"/"+prrel+"/model.phic";
			
			wordMapFile = option.wordMapFileName;
			globalDicFile=option.globalDicFile;
			return true;
		}
		
		/**
		 * Init parameters for estimation
		 */
		
		public boolean initNewModel(DynOption option){
			
			init(option);
			int u, m, n, w, k,c;
			
			p = new double[K];
			pc = new double[CK];
			pb = new double[BK];
			
			Dictionary globalDic=new Dictionary();
			globalDic.readWordMap(globalDicFile);
			data = LocalDataset.readDataSet(U, dir,globalDic);
			
			M = data.M;
			MC = data.MC;
			V = data.V;
			dir = option.dir;
			predir = option.predir;
			
			//read previous files...
			//1. prePhi	
			readPrePhi(prephiFile);
			//2. prePhic	
			readPrePhic(prephicFile);
			//3. preTheta for each user	
			int prrel=relSlices-1;
			readPreTheta(predir+"/"+prrel);
			//4. preThetac for each user
			readPreThetax(predir+"/"+prrel);
			
			
			nw = new int[V][K];
			for (w = 0; w < V; w++){
				for (k = 0; k < K; k++){
					nw[w][k] = 0;
				}
			}
			
			nd = new int[U][][];
			for(u=0;u<U;u++){
				nd[u]=new int[M[u]][K];
				for (m = 0; m < M[u]; m++){
					for (k = 0; k < K; k++){
						nd[u][m][k] = 0;
					}
				}
			}
			
			ndf = new int[U][][];
			for(u=0;u<U;u++){
				ndf[u]=new int[MC[u]][K];
				for (m = 0; m < MC[u]; m++){
					for (k = 0; k < K; k++){
						ndf[u][m][k] = 0;
					}
				}
			}
			
			nwc = new int[V][CK];
			for (w = 0; w < V; w++){
				for (k = 0; k < CK; k++){
					nwc[w][k] = 0;
				}
			}
			
			nwb = new int[V][BK];
			for (w = 0; w < V; w++){
				for (k = 0; k < BK; k++){
					nwb[w][k] = 0;
				}
			}
			
			ndb = new int[U][][];
			for(u=0;u<U;u++){
				ndb[u]=new int[M[u]][BK];
				for (m = 0; m < M[u]; m++){
					for (k = 0; k < BK; k++){
						ndb[u][m][k] = 0;
					}
				}
			}
			
			ndc = new int[U][][];
			for(u=0;u<U;u++){
				ndc[u]=new int[M[u]][CK];
				for (m = 0; m < M[u]; m++){
					for (k = 0; k < CK; k++){
						ndc[u][m][k] = 0;
					}
				}
			}
			
			ndbf = new int[U][][];
			for(u=0;u<U;u++){
				ndbf[u]=new int[MC[u]][BK];
				for (m = 0; m < MC[u]; m++){
					for (k = 0; k < BK; k++){
						ndbf[u][m][k] = 0;
					}
				}
			}
			
			ndcf = new int[U][][];
			for(u=0;u<U;u++){
				ndcf[u]=new int[MC[u]][CK];
				for (m = 0; m < MC[u]; m++){
					for (k = 0; k < CK; k++){
						ndcf[u][m][k] = 0;
					}
				}
			}
			
			nwca=new int[V][3];
			
			for(w=0;w<V;w++){
				for(c=0;c<3;c++){
					nwca[w][c]=0;
				}
			}
			
			ndca=new int[U][][];
			for(u=0;u<U;u++){
				ndca[u]=new int[M[u]][3];
				for(m=0;m<M[u];m++){
					for(c=0;c<3;c++){
						ndca[u][m][c]=0;
					}
				}
			}
			
			ndcaf=new int[U][][];
			for(u=0;u<U;u++){
				ndcaf[u]=new int[MC[u]][3];
				for(m=0;m<MC[u];m++){
					for(c=0;c<3;c++){
						ndcaf[u][m][c]=0;
					}
				}
			}
			
			
			nwsum = new int[K];
			for (k = 0; k < K; k++){
				nwsum[k] = 0;
			}
			
			nwsumc = new int[CK];
			for (k = 0; k < CK; k++){
				nwsumc[k] = 0;
			}
			
			nwsumb = new int[BK];
			for (k = 0; k < BK; k++){
				nwsumb[k] = 0;
			}
			
			ndsum = new int[U][];
			for(u=0;u<U;u++){
				ndsum[u]=new int[M[u]];
				for (m = 0; m < M[u]; m++){
					ndsum[u][m] = 0;
				}
			}
			
			ndfsum = new int[U][];
			for(u=0;u<U;u++){
				ndfsum[u]=new int[MC[u]];
				for (m = 0; m < MC[u]; m++){
					ndfsum[u][m] = 0;
				}
			}
			
			
			
			z = new Vector[U][];
			for(u=0;u<U;u++){
				z[u]=new Vector[M[u]];
			}
			
			zf = new Vector[U][];
			for(u=0;u<U;u++){
				zf[u]=new Vector[MC[u]];
			}
			
			for(u=0;u<U;u++){
				
				//1. user file
				for (m = 0; m < data.M[u]; m++){
					
					int N = data.docs[u][m].length; //the word num, without considering the iteration of the words
					z[u][m] = new Vector<Integer>();
					
					//initilize for z
					for (n = 0; n < N; n++){
						int topic = (int)Math.floor(Math.random() * (K+CK+BK)); //please remember the math.floor 's meaning and this is use it to extract a random topic
						z[u][m].add(topic);
						
						if(topic<K){
							// number of instances of word assigned to topic j
							nw[data.docs[u][m].words[n]][topic] += 1;
							// number of words in document i assigned to topic j
							nd[u][m][topic] += 1;
							ndca[u][m][0]+=1;
							// total number of words assigned to topic j
							nwsum[topic] += 1;
							
						}else if(topic<(K+CK)){
							//common topics
							nwc[data.docs[u][m].words[n]][topic-K] += 1;
							ndc[u][m][topic-K] += 1;
							ndca[u][m][1]+=1;
							nwsumc[topic-K] +=1;
							
						}else{
							nwb[data.docs[u][m].words[n]][topic-CK-K] += 1;
							ndb[u][m][topic-K-CK] += 1;
							ndca[u][m][2]+=1;
							nwsumb[topic-K-CK] +=1;
						}
					}
					// total number of words in document i
					ndsum[u][m] = N;
				}
				//2. candidate file
				for (m = 0; m < data.MC[u]; m++){
					
					int N = data.can_docs[u][m].length; //the word num, without considering the iteration of the words
					zf[u][m] = new Vector<Integer>();
					
					//initilize for z
					for (n = 0; n < N; n++){
						
						int topic = (int)Math.floor(Math.random() * (K+CK+BK)); //please remember the math.floor 's meaning and this is use it to extract a random topic
						zf[u][m].add(topic);
						if(topic<K){
							// number of instances of word assigned to topic j
							
							nw[data.can_docs[u][m].words[n]][topic] += 1;
							
							// number of words in document i assigned to topic j
							ndf[u][m][topic] += 1;
							ndcaf[u][m][0]+=1;
							// total number of words assigned to topic j
							nwsum[topic] += 1;
							
						}else if(topic<(K+CK)){
							//common topics
							nwc[data.can_docs[u][m].words[n]][topic-K] += 1;
							ndcf[u][m][topic-K] += 1;
							ndcaf[u][m][1]+=1;
							nwsumc[topic-K]+=1;
						}else{
							nwb[data.can_docs[u][m].words[n]][topic-K-CK] += 1;
							ndbf[u][m][topic-K-CK] += 1;
							ndcaf[u][m][2]+=1;
							nwsumb[topic-K-CK]+=1;
						}
						
					}
					// total number of words in document i
					ndfsum[u][m] = N;
				}
			}
			
			theta = new double[U][][];
			for(u=0;u<U;u++){
				theta[u]=new double[M[u]][K];
			}
			
			thetaf = new double[U][][];
			for(u=0;u<U;u++){
				thetaf[u]=new double[MC[u]][K];
			}
			
			thetac = new double[U][][];
			for(u=0;u<U;u++){
				thetac[u]=new double[M[u]][CK];
			}
			
			thetab = new double[U][][];
			for(u=0;u<U;u++){
				thetab[u]=new double[M[u]][BK];
			}
			
			thetabf = new double[U][][];
			for(u=0;u<U;u++){
				thetabf[u]=new double[MC[u]][BK];
			}
			
			thetacf = new double[U][][];
			for(u=0;u<U;u++){
				thetacf[u]=new double[MC[u]][CK];
			}
			
			phi = new double[K][V];
			phic = new double[CK][V];
			phib = new double[BK][V];
			
			return true;
		}
	
	
}
