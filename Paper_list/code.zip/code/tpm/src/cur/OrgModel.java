package cur;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.StringTokenizer;
import java.util.Vector;
import java.lang.Number;
import java.math.BigDecimal;
import pub.*;
  
public class OrgModel {
	//---------------------------------------------------------------
	//	Class Variables
	//---------------------------------------------------------------
	
	//public static String tassignSuffix;	//suffix for topic assignment file
	
	public static String thetaSuffix;		//suffix for theta (topic - document distribution) file
	public static String thetaSuffixb;		//suffix for thetab (common topic - document distribution) file
	public static String thetaSuffixf;		//suffix for thetaf (topic - candidate document distribution) file
	public static String thetaSuffixbf;		//suffix for thetabf (common topic - candiate document distribution) file
	public static String phiSuffix;		//suffix for phi file (topic - word distribution) file
	public static String phiSuffixc; //suffix for phib file (common topic - word distribution) file
	
	//---------------------------------------------------------------
	//	Model Parameters and Variables
	//---------------------------------------------------------------
	
	LocalDataset data;
	
	public String wordMapFile; 		//file that contain word to id map
	public String globalDicFile;
	public String dir;
	public int U;
	
	public int[] M; //dataset size (i.e., number of docs for each user)
	public int[] MC; //dataset candidate size (number of candidate docs for each user)
	public int V; //vocabulary size
	public int K; //number of topics
	public int BK; //number of burst topics
	
	//LDA  hyperparameters
	public double alpha;
	public double beta; //sim between cur slice and pre ones...K*relSlices...
	public double alphab;
	public double betab;
	public double gamma; //dirichlet prior for user-topic category
	public double sigma; //dirichlet prior for can-topic category
	
	public int niters; //number of Gibbs sampling iteration
	
	// Estimated/Inferenced parameters
	public double [][][] theta; //theta: document - topic distributions, size U x M x K
	public double [][][] thetab; //thetab: document - burst topic distributions, size U x M x BK
	public double [][] phi; // phi: topic-word distributions, size K x V
	public double [][] phib; //phib: burst topic-word distributions, size  BK x V
	public double [][][] thetaf; //theta: candidate document - topic distributions, size U x M x K
	public double [][][] thetabf; //thetab: candiate document - burst topic distributions, size U x M x BK
	
	
	// Temp variables while sampling
	public Vector<Integer> [][] z; //topic assignments for words, size U x M x doc.size()
	public Vector<Integer> [][] zf; //topic assignments for words, size U x MC x doc.size()
	
	//private
	protected int [][] nw; //nw[i][j]: number of instances of word/term i assigned to topic j, size V x K
	protected int [][][] nd; //nd[i][j]: number of words in document i assigned to topic j, size U x M x K
	protected int [][][] ndf; //nd[i][j]: number of words in document i (candiate files) assigned to topic j, size U x MC x K
	//burst 
	protected int [][] nwb; //nwb[i][j]: number of instances of word/term i assigned to topic j, size V x BK
	protected int [][][] ndb; //ndb[i][j]: number of words in document i assigned to topic j, size U x M x BK
	protected int [][][] ndbf; //ndbf[i][j]: number of words in document i (candiate files) assigned to topic j, size U x MC x BK
	
	protected int [][] nwca; //nwb[i][j]: number of instances of words i assigned to topic category, size V x 2 
	protected int [][][] ndca; //ndca[i][j]: number of words in document i assigned to category j, size U x M x 2
	protected int [][][] ndcaf;//ndcaf[i][j]: number of words in candidate document i assigned to category j, size U x MCx 2
	
	protected int [] nwsum; //nwsum[j]: total number of words assigned to topic j, size K
	protected int [] nwsumb; //nwsumb[j]: total number of words assigned to topic j, size BK
	protected int [][] ndsum; //ndsum[i]: total number of words in document i, size U x M
	protected int [][] ndfsum; //ndsum[i]: total number of words in candidate document i, size U x MC
	
	// temp variables for sampling
	protected double [] p; 
	protected double [] pb;
	
	//---------------------------------------------------------------
	//	Constructors
	//---------------------------------------------------------------	
	public OrgModel(){
		setDefaultValues();	
	}
	
	/**
	 * Set default values for variables
	 */
	public void setDefaultValues(){
		wordMapFile = "wordmap.txt";
		thetaSuffix = ".theta";
		thetaSuffixf = ".thetaf";
		thetaSuffixb = ".thetab";
		thetaSuffixbf = ".thetabf";
		phiSuffix = ".phi";
		phiSuffixc = ".phic";
		
		dir = "./";	
		data =null;
		M = null;
		MC = null;
		U=0;
		V = 0;
		K = 100;
		BK =100;
		alpha=50.0/K;
		alphab =50.0/BK;
		beta=0.1;
		betab=0.1;
		
		niters = 2000;
		z = null;
		zf = null;
		nw = null;
		nd = null;
		ndf = null;
		nwb = null;
		ndb = null;
		ndbf = null;
		
		nwca =null;
		ndca =null;
		ndcaf=null;
		
		nwsum = null;
		nwsumb = null;
		ndsum = null;
		ndfsum = null;
		
		
		theta = null;
		thetab = null;
		thetaf = null;
		thetabf = null;
		phi = null;
		phib =null;
	}
	
	//---------------------------------------------------------------
	//	I/O Methods
	//---------------------------------------------------------------
	
	
	/**
	 * Save theta (topic distribution) for this model
	 */
	public boolean saveModelTheta(String filename,int udx){
		try{
			BufferedWriter writer = new BufferedWriter(new FileWriter(filename));
				for (int j = 0; j < K; j++){
					double thetasum=0.0;
					for (int i = 0; i < M[udx]; i++){
						thetasum+=theta[udx][i][j];
					}
					
					BigDecimal b = new BigDecimal(thetasum);  
					thetasum=b.setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
					writer.write(thetasum + " ");
				}
			writer.write("\n");
			writer.close();
		}
		catch (Exception e){
			System.out.println("Error while saving topic distribution file for this model: " + e.getMessage());
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	/**
	 * Save thetab (common topic distribution) for this model
	 */
	public boolean saveModelThetab(String filename, int udx){
		try{
			BufferedWriter writer = new BufferedWriter(new FileWriter(filename));
			
			for (int j = 0; j < BK; j++){
				double thetasum=0.0;
				for (int i = 0; i < M[udx]; i++){
					thetasum+=thetab[udx][i][j];
				}
				BigDecimal b = new BigDecimal(thetasum);  
				thetasum=b.setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
				writer.write(thetasum + " ");
			}
			writer.write("\n");
			writer.close();
		}
		catch (Exception e){
			System.out.println("Error while saving topic distribution file for this model: " + e.getMessage());
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	/**
	 * Save thetaf (topic-candidate doc distribution) for this model
	 */
	public boolean saveModelThetaf(String filename,int udx){
		try{
			BufferedWriter writer = new BufferedWriter(new FileWriter(filename));
			for (int i = 0; i < MC[udx]; i++){
				for (int j = 0; j < K; j++){
					writer.write(thetaf[udx][i][j] + " ");
				}
				writer.write("\n");
			}
			writer.close();
		}
		catch (Exception e){
			System.out.println("Error while saving topic distribution file for this model: " + e.getMessage());
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	
	
	/**
	 * Save thetabf (common topic-candiate doc distribution) for this model
	 */
	public boolean saveModelThetabf(String filename,int udx){
		try{
			BufferedWriter writer = new BufferedWriter(new FileWriter(filename));
			for (int i = 0; i < MC[udx]; i++){
				for (int j = 0; j < BK; j++){
					writer.write(thetabf[udx][i][j] + " ");
				}
				writer.write("\n");
			}
			writer.close();
		}
		catch (Exception e){
			System.out.println("Error while saving topic distribution file for this model: " + e.getMessage());
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
		
	/**
	 * Save word-topic distribution
	 */
	
	public boolean saveModelPhi(String filename){
		try {
			double[] phis=new double[K];
			for (int i = 0; i < K; i++){
				for (int j = 0; j < V; j++){					
					phis[i]+=phi[i][j];
				}
			}
			
			
			BufferedWriter writer = new BufferedWriter(new FileWriter(filename));
			
			for (int i = 0; i < K; i++){
				for (int j = 0; j < V; j++){
					phi[i][j]=phi[i][j]/phis[i];
					BigDecimal b = new BigDecimal(phi[i][j]);
					phi[i][j]=b.setScale(4, BigDecimal.ROUND_HALF_UP).doubleValue();
					writer.write(phi[i][j] + " ");
				}
				writer.write("\n");
			}
			writer.close();
		}
		catch (Exception e){
			System.out.println("Error while saving word-topic distribution:" + e.getMessage());
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	/**
	 * Save word-common topic distribution
	 */
	
	public boolean saveModelPhib(String filename){
		try {
			double[] phis=new double[BK];
			for (int i = 0; i < BK; i++){
				for (int j = 0; j < V; j++){					
					phis[i]+=phib[i][j];
				}
			}
			
			BufferedWriter writer = new BufferedWriter(new FileWriter(filename));
			
			for (int i = 0; i < BK; i++){
				for (int j = 0; j < V; j++){
					phib[i][j]=phib[i][j]/phis[i];
					BigDecimal b = new BigDecimal(phib[i][j]);
					phib[i][j]=b.setScale(4, BigDecimal.ROUND_HALF_UP).doubleValue();
					writer.write(phib[i][j] + " ");
				}
				writer.write("\n");
			}
			writer.close();
		}
		catch (Exception e){
			System.out.println("Error while saving word-topic distribution:" + e.getMessage());
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	
	/**
	 * Save other information of this model for each user... filename should be considered user's id... see saveModel method...
	 */
	public boolean saveModelOthers(String filename){
		try{
			BufferedWriter writer = new BufferedWriter(new FileWriter(filename));
			
			writer.write("alpha=" + alpha + "\n");
			writer.write("alphab=" + alphab + "\n");
			writer.write("beta=" + beta + "\n");
			writer.write("betab=" + betab + "\n");
			writer.close();
		}
		catch(Exception e){
			System.out.println("Error while saving model others:" + e.getMessage());
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	/**
	 * Save model
	 */
	public void saveModel(int udx){
		saveModelOthers(dir + "/" + udx + ".others");
		saveModelTheta(dir + "/" + udx + thetaSuffix, udx);
		saveModelThetab(dir + "/" + udx + thetaSuffixb, udx);
		saveModelThetaf(dir + "/" + udx + thetaSuffixf, udx);
		saveModelThetabf(dir + "/" + udx + thetaSuffixbf, udx);
	}
	
	//---------------------------------------------------------------
	//	Init Methods
	//---------------------------------------------------------------
	/**
	 * initialize the model
	 */
	protected boolean init(DynOption option){		
		
		K = option.K;
		BK = option.BK;
		U=option.nuser;
		alpha=50.0/K;
		alphab=50.0/BK;
		beta=0.1;
		betab=0.1;
		gamma=0.33;
		sigma=0.33;
		niters = option.niters;
		
		dir = option.dir;
		
		if (dir.endsWith("/"))
			dir = dir.substring(0, dir.length() - 1);
		
		wordMapFile = option.wordMapFileName;
		globalDicFile=option.globalDicFile;
		return true;
	}
	
	/**
	 * Init parameters for estimation
	 */
	
	public boolean initNewModel(DynOption option){
		
		init(option);
		int u, m, n, w, k,c;
		
		p = new double[K];
		pb = new double[BK];
		
		Dictionary globalDic=new Dictionary();
		globalDic.readWordMap(globalDicFile);
		data = LocalDataset.readDataSet(U, dir,globalDic);
		M=new int[U];
		MC=new int[U];
		
		M = data.M;
		MC = data.MC;
		
		V = data.V;
		dir = option.dir;
		
		nw = new int[V][K];
		for (w = 0; w < V; w++){
			for (k = 0; k < K; k++){
				nw[w][k] = 0;
			}
		}
		
		nd = new int[U][][];
		for(u=0;u<U;u++){
			nd[u]=new int[M[u]][K];
			for (m = 0; m < M[u]; m++){
				for (k = 0; k < K; k++){
					nd[u][m][k] = 0;
				}
			}
		}
		
		ndf = new int[U][][];
		for(u=0;u<U;u++){
			ndf[u]=new int[MC[u]][K];
			for (m = 0; m < MC[u]; m++){
				for (k = 0; k < K; k++){
					ndf[u][m][k] = 0;
				}
			}
		}
		
		nwb = new int[V][BK];
		for (w = 0; w < V; w++){
			for (k = 0; k < BK; k++){
				nwb[w][k] = 0;
			}
		}
		
		ndb = new int[U][][];
		for(u=0;u<U;u++){
			ndb[u]=new int[M[u]][BK];
			for (m = 0; m < M[u]; m++){
				for (k = 0; k < BK; k++){
					ndb[u][m][k] = 0;
				}
			}
		}
		
		ndbf = new int[U][][];
		for(u=0;u<U;u++){
			ndbf[u]=new int[MC[u]][BK];
			for (m = 0; m < MC[u]; m++){
				for (k = 0; k < BK; k++){
					ndbf[u][m][k] = 0;
				}
			}
		}
		
		nwca=new int[V][2];
		for(w=0;w<V;w++){
			for(c=0;c<2;c++){
				nwca[w][c]=0;
			}
		}
		
		ndca=new int[U][][];
		for(u=0;u<U;u++){
			ndca[u]=new int[M[u]][2];
			for(m=0;m<M[u];m++){
				for(c=0;c<2;c++){
					ndca[u][m][c]=0;
				}
			}
		}
		
		ndcaf=new int[U][][];
		for(u=0;u<U;u++){
			ndcaf[u]=new int[MC[u]][2];
			for(m=0;m<MC[u];m++){
				for(c=0;c<2;c++){
					ndcaf[u][m][c]=0;
				}
			}
		}
		
		
		nwsum = new int[K];
		for (k = 0; k < K; k++){
			nwsum[k] = 0;
		}
		
		nwsumb = new int[BK];
		for (k = 0; k < BK; k++){
			nwsumb[k] = 0;
		}
		
		ndsum = new int[U][];
		for(u=0;u<U;u++){
			ndsum[u]=new int[M[u]];
			for (m = 0; m < M[u]; m++){
				ndsum[u][m] = 0;
			}
		}
		
		ndfsum = new int[U][];
		for(u=0;u<U;u++){
			ndfsum[u]=new int[MC[u]];
			for (m = 0; m < MC[u]; m++){
				ndfsum[u][m] = 0;
			}
		}
		
		z = new Vector[U][];
		for(u=0;u<U;u++){
			z[u]=new Vector[M[u]];
		}
		
		zf = new Vector[U][];
		for(u=0;u<U;u++){
			zf[u]=new Vector[MC[u]];
		}
		
		for(u=0;u<U;u++){
			
			//1. user file
			for (m = 0; m < data.M[u]; m++){
				
				int N = data.docs[u][m].length; //the word num, without considering the iteration of the words
				z[u][m] = new Vector<Integer>();
				
				//initilize for z
				for (n = 0; n < N; n++){
					int topic = (int)Math.floor(Math.random() * (K+BK)); //please remember the math.floor 's meaning and this is use it to extract a random topic
					z[u][m].add(topic);
					
					if(topic<K){
						// number of instances of word assigned to topic j
						nw[data.docs[u][m].words[n]][topic] += 1;
						// number of words in document i assigned to topic j
						nd[u][m][topic] += 1;
						ndca[u][m][0]+=1;
						// total number of words assigned to topic j
						nwsum[topic] += 1;
						
					}else{
						nwb[data.docs[u][m].words[n]][topic-K] += 1;
						ndb[u][m][topic-K] += 1;
						ndca[u][m][1]+=1;
						nwsumb[topic-K] +=1;
					}
				}
				// total number of words in document i
				ndsum[u][m] = N;
			}
			
			//2. candidate file
			for (m = 0; m < data.MC[u]; m++){
				
				int N = data.can_docs[u][m].length; //the word num, without considering the iteration of the words
				zf[u][m] = new Vector<Integer>();
				
				//initilize for z
				for (n = 0; n < N; n++){
					int topic = (int)Math.floor(Math.random() * (K+BK)); //please remember the math.floor 's meaning and this is use it to extract a random topic
					zf[u][m].add(topic);
					
					if(topic<K){
						// number of instances of word assigned to topic j
						nw[data.can_docs[u][m].words[n]][topic] += 1;
						// number of words in document i assigned to topic j
						ndf[u][m][topic] += 1;
						ndcaf[u][m][0]+=1;
						// total number of words assigned to topic j
						nwsum[topic] += 1;
					}else{
						nwb[data.can_docs[u][m].words[n]][topic-K] += 1;
						ndbf[u][m][topic-K] += 1;
						ndcaf[u][m][1]+=1;
						nwsumb[topic-K]+=1;
					}
				}
				// total number of words in document i
				ndfsum[u][m] = N;
			}
			
		}
		
		theta = new double[U][][];
		for(u=0;u<U;u++){
			theta[u]=new double[M[u]][K];
		}
		
		thetaf = new double[U][][];
		for(u=0;u<U;u++){
			thetaf[u]=new double[MC[u]][K];
		}
		
		thetab = new double[U][][];
		for(u=0;u<U;u++){
			thetab[u]=new double[M[u]][BK];
		}
		
		thetabf = new double[U][][];
		for(u=0;u<U;u++){
			thetabf[u]=new double[MC[u]][BK];
		}
		
		phi = new double[K][V];
		phib = new double[BK][V];
		
		return true;
	}
	
}
