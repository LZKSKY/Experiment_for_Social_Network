package summary;
import java.util.*;
public class Document {
	public String content;
	public double[] topics;
	public int index; //index in matrix...
	public int getIndex() {
		return index;
	}
	public void setIndex(int index) {
		this.index = index;
	}
	public double kl_div; //kl_divgence with u_topic...
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public double[] getTopics() {
		return topics;
	}
	public void setTopics(double[] topics) {
		this.topics = topics;
	}
	public double getKl_div() {
		return kl_div;
	}
	public void setKl_div(double kl_div) {
		this.kl_div = kl_div;
	}
	
}
