package summary;
import java.io.*;
import java.util.*;

public class IpgSummary {

	static int uidx=1;
	static String IN_DIR="/Users/zhaochunren/dataset/example_sigir13";
	
	static int utopic=20;
	static int ctopic=20;
	static int btopic=20;
	static int T=3; //slices...
	static int R=5; //length of summary
	
	public static String[] readDocs(String filename){
		
		try{
			String[] docs;
			BufferedReader reader=new BufferedReader(new InputStreamReader(new FileInputStream(filename),"UTF-8"));
			int nod=Integer.parseInt(reader.readLine());
			docs=new String[nod];
			for(int i=0;i<nod;i++){
				docs[i]=reader.readLine();
			}
			
			reader.close();
			
			return docs; 
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return null;
	}
	
	public static double[] readUtopic(String dir, int udx, int utopic){
		try{
			//user theta...
			BufferedReader reader=new BufferedReader(new InputStreamReader(new FileInputStream(dir+"/"+udx+".theta"),"UTF-8"));
			String[] xl=reader.readLine().split(" ");
			double[] user_td=new double[utopic];
			double sum=0.0;
			for(int i=0;i<user_td.length;i++){
				user_td[i]=Double.parseDouble(xl[i]);
				sum+=user_td[i];
			}
			reader.close();
			//normalize...
			for(int i=0;i<utopic;i++){
				user_td[i]=user_td[i]/sum;
			}
			
			return user_td;
			
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
	}
	
	public static double[][] readCUtopic(String dir, int udx, int utopic){
		try{
			ArrayList<double[]> cutb=new ArrayList<double[]>();
			BufferedReader reader=new BufferedReader(new InputStreamReader(new FileInputStream(dir+"/"+udx+".thetaf"),"UTF-8"));
			String line =null;
			while((line=reader.readLine())!=null){
				String[] sxs=line.split(" ");
				double[] cud=new double[utopic];
				double sum=0.0;
				for(int i =0;i<utopic;i++){
					cud[i]=Double.parseDouble(sxs[i]);
					sum+=cud[i];
				}
				//normalize...
				for(int i=0;i<utopic;i++){
					cud[i]=cud[i]/sum;
				}
				cutb.add(cud);
			}
			
			reader.close();
			
			double[][] res=new double[cutb.size()][utopic];
			for(int i=0;i<cutb.size();i++){
				res[i]=cutb.get(i);
			}
			
			return res;
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
	}
	
	public static double[] readUBtopic(String dir, int udx, int ctopic){
		try{
			BufferedReader reader=new BufferedReader(new InputStreamReader(new FileInputStream(dir+"/"+udx+".thetab"),"UTF-8"));
			String[] xl=reader.readLine().split(" ");
			double[] user_td=new double[ctopic];
			double sum=0.0;
			for(int i=0;i<user_td.length;i++){
				user_td[i]=Double.parseDouble(xl[i]);
				sum+=user_td[i];
			}
			reader.close();
			//normalize...
			for(int i=0;i<ctopic;i++){
				user_td[i]=user_td[i]/sum;
			}
			
			return user_td;
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
	}
	
	
	public static double[][] readCBtopic(String dir, int udx, int ctopic){
		
		try{
			
			ArrayList<double[]> cutb=new ArrayList<double[]>();
			BufferedReader reader=new BufferedReader(new InputStreamReader(new FileInputStream(dir+"/"+udx+".thetabf"),"UTF-8"));
			String line =null;
			while((line=reader.readLine())!=null){
				String[] sxs=line.split(" ");
				double[] cud=new double[ctopic];
				double sum=0.0;
				for(int i =0;i<ctopic;i++){
					cud[i]=Double.parseDouble(sxs[i]);
					sum+=cud[i];
				}
				//normalize...
				for(int i=0;i<ctopic;i++){
					cud[i]=cud[i]/sum;
				}
				cutb.add(cud);
			}
			
			reader.close();
			
			double[][] res=new double[cutb.size()][ctopic];
			for(int i=0;i<cutb.size();i++){
				res[i]=cutb.get(i);
			}
			
			return res;
			
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
	}
	
	
	public static double divergence(double[] a, double[] b, double[] u){
		
		double res=0.0;
		int k=a.length;
		for(int i=0;i<k;i++){
			double sum=a[i]*Math.log(a[i]/u[i])-b[i]*Math.log(b[i]/u[i]);
			sum=Math.abs(sum);
			res+=sum;
		}
		return res;
	}
	
	public static double div_item(double a, double b, double u){
		double res=0.0;
		res=Math.abs(a*Math.log(a/u)-b*Math.log(b/u));
		return res;
	}
	
	public static double novelty(double[][] a, double[][] b, double[] u){
		
		double res=0.0;
		
		for(int i=0;i<a.length;i++){
			double[] cp=a[i];
			double mindiv=divergence(cp,b[0],u);
			
			if(b.length>1){
				for(int j=1;j<b.length;j++){
					double ccdiv=divergence(cp,b[j],u);
					if(ccdiv<mindiv){
						mindiv=ccdiv;
					}
				}
			}
			
			res+=mindiv;
		}
		res=res/a.length;
		return res;
	}
	
	public static double coverage(double[][] a, double[][] b, double[] u){

		double res=0.0;
		int z=u.length;
		for(int i=0;i<a.length;i++){
			//double[] cp=a[i];
			int sz=0;
			double ssum=0.0;
			for(int j=0;j<b.length;j++){
				ssum+=div_item(a[i][sz],b[j][sz],u[sz]);
			}
			ssum=ssum/b.length;
			for(int k=0;k<z;k++){
				double csum=0.0;
				for(int j=0;j<b.length;j++){
					csum+=div_item(a[i][k],b[j][k],u[k]);
				}
				csum=csum/b.length;
				if(csum<ssum){
					ssum=csum;
				}
			}
			
			res+=Math.pow(Math.E, ssum*(-1));
		}
		res=res/a.length;
		return res;
	}
	
	public static double diversity(double[][] a, double[][] b){

		double res=0.0;
		double[] xb=new double[b[0].length];
		for(int z=0;z<xb.length;z++){
			xb[z]=b[0][z];
			for(int i=0;i<b.length;i++){
				xb[z]=xb[z]*b[i][z];
			}
		}
		
		for(int i=0;i<a.length;i++){
			for(int j=0;j<a.length;j++){
				double div=divergence(a[i],a[j],xb);
				res+=div;
			}
		}
		res=res/(a.length*a.length);
		return res;
	}
	
	public static double[][] calMatr(int not,Document[] summary, double[][] cantheta){
		double[][] stf=new double[R][not];
		for(int i=0;i<R;i++){
			Document dc=summary[i];
			int did=dc.index;
			double[] df=cantheta[did];
			stf[i]=df;
		}
		return stf;
	}
	
	public static double[][] calMatrPre(int not,Document[] summary, double[][] cantheta){
		double[][] stf=new double[R][not];
		for(int i=0;i<R;i++){
			Document dc=summary[i];
			int did=dc.index;
			double[] df=cantheta[did];
			for(int j=0;j<not;j++){
				stf[i][j]=df[j];
			}
		}
		return stf;
	}
	
	
	public static Document[] sort(Document[] docs){
		Document[] res=docs;
		for(int i=0;i<res.length;i++){
			if(i<res.length-1){
				for(int j=i+1;j<res.length;j++){
					if(res[j].kl_div<res[i].kl_div){
						Document xxx=res[j];
						res[j]=res[i];
						res[i]=xxx;
					}
				}
			}
		}
		
		return res;
	}
	
	public static void main(String[] args) {

		double[][] pre_res;
		Document[] docs;
		Document[] summary;
		double threshold=0.001;
		
		ArrayList<Document[]> summary_pre=new ArrayList<Document[]>();
		
		try{
			String[] can_str=readDocs(IN_DIR+"/"+0+"/"+uidx+".can");
			double[] cur_uu=new double[utopic];
			double[] cur_uc=new double[btopic];
			double[][] can_uu=new double[can_str.length][utopic]; //M*K
			double[][] can_uc=new double[can_str.length][btopic]; //M*BK
			
			cur_uu=readUtopic(IN_DIR+"/"+0, uidx, utopic);
			cur_uc=readUBtopic(IN_DIR+"/"+0, uidx, btopic);
			can_uu=readCUtopic(IN_DIR+"/"+0, uidx, utopic);
			can_uc=readCBtopic(IN_DIR+"/"+0, uidx, btopic);
			docs=new Document[can_str.length];
			
			double[][] cantheta=new double[can_str.length][utopic+btopic];
			for(int i=0;i<cantheta.length;i++){
				for(int j=0;j<utopic;j++){
					cantheta[i][j]=can_uu[i][j];
				}
				
				for(int j=0;j<btopic;j++){
					cantheta[i][j+utopic]=can_uc[i][j];
				}
			}
			double[] utheta = new double[utopic+btopic];
			for(int i=0;i<utopic;i++){
				utheta[i]=cur_uu[i];
			}
			for(int i=0;i<btopic;i++){
				utheta[i+utopic]=cur_uc[i];
			}
			//
			double[] kldivs=new double[can_str.length];
			for(int i=0;i<kldivs.length;i++){
				kldivs[i]=KLDivergence.kldiv(cantheta[i], utheta);
				//System.out.println(kldivs[i]);
			}
			
			for(int i=0;i<docs.length;i++){
				Document doc=new Document();
				doc.content=can_str[i];
				doc.kl_div=kldivs[i];
				doc.topics=cantheta[i];
				doc.index=i;
				docs[i]=doc;
				//System.out.println(doc.kl_div);
			}
			//sort by kl div
			Document[] sdocs=sort(docs);
			//
			summary=new Document[R];
			//Document[] csummary=new Document[R];
			
			if(sdocs.length>R){
				for(int i=0;i<R;i++){
					summary[i]=sdocs[i];
				}
				Document[] rest=new Document[sdocs.length-R];
				for(int i=R;i<sdocs.length;i++){
					rest[i-R]=sdocs[i];
				}
				//
				double[][] stf=calMatr(utheta.length,summary,cantheta);
				
				double score=coverage(stf,cantheta,utheta)*diversity(stf,cantheta);
				double descore=0.1;
				int count=0;
				while(threshold<=descore){
					count++;
					//init pair:  <0,R-1>
					Document cs=rest[0];
					int pos=R-1;
					int cpos=0;
					rest[0]=summary[R-1];
					summary[R-1]=cs;
					stf=calMatr(utheta.length,summary,cantheta);
					double score1=coverage(stf,cantheta,utheta)*diversity(stf,cantheta)-score;
					summary[R-1]=rest[0];
					rest[0]=cs;
					
					for(int j=0;j<rest.length;j++){
						for(int p=R-1;p>=0;p--){
							rest[j]=summary[p];
							summary[p]=cs;
							stf=calMatr(utheta.length,summary,cantheta);
							double score2=coverage(stf,cantheta,utheta)*diversity(stf,cantheta)-score;
							if((score2>score1)&(score2>0)){
								pos=p;
								cpos=j;
								score1=score2;
							}
							summary[p]=rest[j];
							rest[j]=cs;
						}
					}
					
					//replace...
					if(score1>0){
						cs=summary[pos];
						summary[pos]=rest[cpos];
						rest[cpos]=cs;
						descore=score1;
					}
					if(count>50)
						break;
					
				}
				summary_pre.add(summary);
				
			}else{
				summary_pre.add(sdocs);
			}
			
			//for t>0...
			for(int t=1;t<=T;t++){
				
				can_str=readDocs(IN_DIR+"/"+t+"/"+uidx+".can");
				cur_uu=new double[utopic];
				cur_uc=new double[ctopic+btopic];
				can_uu=new double[can_str.length][utopic]; //M*K
				can_uc=new double[can_str.length][ctopic+btopic]; //M*BK
				double[] uthetap=new double[utopic+ctopic];
				cur_uu=readUtopic(IN_DIR+"/"+t, uidx, utopic);
				cur_uc=readUBtopic(IN_DIR+"/"+t, uidx, ctopic+btopic);
				can_uu=readCUtopic(IN_DIR+"/"+t, uidx, utopic);
				can_uc=readCBtopic(IN_DIR+"/"+t, uidx, ctopic+btopic);
				docs=new Document[can_str.length];
				
				cantheta=new double[can_str.length][utopic+ctopic+btopic];
				for(int i=0;i<cantheta.length;i++){
					for(int j=0;j<utopic;j++){
						cantheta[i][j]=can_uu[i][j];
					}
					
					for(int j=0;j<ctopic+btopic;j++){
						cantheta[i][j+utopic]=can_uc[i][j];
					}
				}
				utheta = new double[utopic+ctopic+btopic];
				for(int i=0;i<utopic;i++){
					utheta[i]=cur_uu[i];
				}
				for(int i=0;i<ctopic+btopic;i++){
					utheta[i+utopic]=cur_uc[i];
				}
				for(int i=0;i<utopic+ctopic;i++){
					uthetap[i]=utheta[i];
				}
				
				//
				kldivs=new double[can_str.length];
				for(int i=0;i<kldivs.length;i++){
					kldivs[i]=KLDivergence.kldiv(cantheta[i], utheta);
				}
				
				for(int i=0;i<docs.length;i++){
					Document doc=new Document();
					doc.content=can_str[i];
					doc.kl_div=kldivs[i];
					doc.topics=cantheta[i];
					doc.index=i;
					docs[i]=doc;
				}
				
				sdocs=sort(docs);
				//
				summary=new Document[R];
				
				
				if(sdocs.length>R){
					for(int i=0;i<R;i++){
						summary[i]=sdocs[i];
						
					}
					Document[] rest=new Document[sdocs.length-R];
					for(int i=R;i<sdocs.length;i++){
						rest[i-R]=sdocs[i];
					}
					
					Document[] ss=summary_pre.get(t-1);
					
					double[][] tfss=new double[ss.length][utopic+ctopic];
					for(int u=0;u<tfss.length;u++){
						tfss[u]=ss[u].getTopics();
					}
					//
					
					double[][] stf=calMatr(utheta.length,summary,cantheta);
					double[][] stfp=calMatrPre(utopic+ctopic,summary,cantheta);
					
					double score=novelty(stfp,tfss,uthetap)*coverage(stf,cantheta,utheta)*diversity(stf,cantheta);
					double descore=0.1;
					int count=0;
					while(threshold<=descore){
						
						count++;
						Document cs=rest[0];
						int pos=R-1;
						int cpos=0;
						rest[0]=summary[R-1];
						summary[R-1]=cs;
						stf=calMatr(utheta.length,summary,cantheta);
						double score1=coverage(stf,cantheta,utheta)*diversity(stf,cantheta)-score;
						
						summary[R-1]=rest[0];
						rest[0]=cs;
						
						for(int j=0;j<rest.length;j++){
							for(int p=R-1;p>=0;p--){
								rest[j]=summary[p];
								summary[p]=cs;
								stf=calMatr(utheta.length,summary,cantheta);
								stfp=calMatrPre(utopic+ctopic,summary,cantheta);
								double score2=novelty(stfp,tfss,uthetap)*coverage(stf,cantheta,utheta)*diversity(stf,cantheta)-score;
								if((score2>score1)&&(score2>0)){
									pos=p;
									cpos=j;
									score1=score2;
								}
								summary[p]=rest[j];
								rest[j]=cs;
							}
						}
						
						if(score1>0){
							//replace...
							cs=summary[pos];
							summary[pos]=rest[cpos];
							rest[cpos]=cs;
							descore=score1;
						}
						if(count>50)
							break;
					}
					summary_pre.add(summary);
					
				}else{
					summary_pre.add(sdocs);
				}
				
				ctopic+=btopic;
			}
			
			//show summary...
			for(int t=0;t<=T;t++){
				Document[] sum=summary_pre.get(t);
				System.out.println("the "+ t+"th slice summary for user "+uidx+"is:  ***********************************");
				for(int i=0;i<sum.length;i++){
					System.out.println("The"+i+"th doc: "+ sum[i].content);
				}
				System.out.println("************************************************************************************");
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}

}
