package summary;
import java.util.*;

public class KLDivergence {
	
	public static double kldiv(double[] a, double[] b){
		double res=0.0;
		
		for (int i = 0; i < a.length; ++i) {
	        if (a[i] == 0) { 
	        	continue; 
	        }
	        
	        if (b[i] == 0.0){ 
	        	continue; 
	        } 

	        res += a[i] * Math.log( a[i] / b[i] );
	    
		}
		res=res/Math.log(2);
		
		return res;
	}
	
	
}
