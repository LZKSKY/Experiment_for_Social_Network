package usageTool;
import java.util.*;
import java.math.*;
import beans.*;
import java.io.*;
  
public class MatchArraylist {
 public static boolean mathcArraylist(ArrayList<String> a,ArrayList<Word> b){
	 boolean decision=true;
	 if(a.size()!=b.size())
		 return false;
	 else{
		 ArrayList<String> b_w=new ArrayList<String>(0);
		 for(int i=0;i<b.size();i++){
			 b_w.add(b.get(i).word);
		 }
	     int num=a.size();
		 for(int i=0;i<num;i++){
		    if(!(b_w.contains(a.get(i))))
		    		decision=false;
		 }
		 return decision;
	 }
 }
 
 
 public static void processFile(String input,String output){
	 BufferedReader reader;
	 PrintWriter writer;
	 try{
		 
		 
	 }catch(Exception e){
		System.out.println(e.getMessage()); 
	 }
 }
 
 
 public static boolean matchAtFromAts(ArrayList<AuthorTime> ats,AuthorTime at){
	 boolean tar=false;
	 
	 for(int i=0;i<ats.size();i++){
		 AuthorTime tmp_at=ats.get(i);
		 String au=tmp_at.author;
		 String ti=tmp_at.time;
		 if((au.equals(at.author))&&(ti.equals(at.time))){
			 tar=true;
			 break;
		 }
	 }
	 
	 return tar;
 }
 
 
 
 
}
