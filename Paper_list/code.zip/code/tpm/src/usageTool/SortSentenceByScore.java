package usageTool;
import java.math.*;

import java.util.*;
import beans.*;
public class SortSentenceByScore {
     
	public static ArrayList<Sentence> sens;
	public static ArrayList<Sentence> sens_lda;
	//score
	public static void sortByScore(int begin,int end){
		//quick sorting...
		if(begin<end){
		  int x=partition(begin,end);
		  sortByScore(begin,x-1);
		  sortByScore(x+1,end);
		}
	}
	//lda_score
	public static void sortByScore_lda(int begin,int end){
		if(begin<end){
			  int x=partition_lda(begin,end);
			  sortByScore_lda(begin,x-1);
			  sortByScore_lda(x+1,end);
			}
	}
	
	public static int partition_lda( int p,int r){
		double threshHold=sens.get(r).score_lda;
		//System.out.println(threshHold+"?");
		
		
		int x=p-1;
		
		for(int i=p;i<=r-1;i++){
			if(sens.get(i).score_lda<=threshHold){
				
				
				
				x++;
				
				//System.out.println(x+"!");
				Sentence sen_0=sens.get(i);
				Sentence sen_1=sens.get(x);
				sens.remove(i);
				sens.add(i,sen_1);
				sens.remove(x);
				sens.add(x,sen_0);
				
				//for(int o=0;o<sens.size();o++){
		        	//System.out.println(sens.get(o).number+":");
		        //}
				
			}
		}
		
		//System.out.println(x);
		Sentence sen_3=sens.get(x+1);
		//System.out.println(sen_3.number);
		Sentence sen_4=sens.get(r);
		//System.out.println(sen_4.number);
		sens.remove(x+1);
		sens.add(x+1,sen_4);
		
		sens.remove(r);				
		sens.add(r,sen_3);
		//for(int o=0;o<sens.size();o++){
        //	System.out.println(sens.get(o).number);
        //}
		
		
		return x+1;
	}
	
	
	public static int partition( int p,int r){
		
		double threshHold=sens.get(r).score;
		//System.out.println(threshHold+"?");
		
		
		int x=p-1;
		
		for(int i=p;i<=r-1;i++){
			if(sens.get(i).score<=threshHold){
				
				
				
				x++;
				
				//System.out.println(x+"!");
				Sentence sen_0=sens.get(i);
				Sentence sen_1=sens.get(x);
				sens.remove(i);
				sens.add(i,sen_1);
				sens.remove(x);
				sens.add(x,sen_0);
				
				//for(int o=0;o<sens.size();o++){
		        	//System.out.println(sens.get(o).number+":");
		        //}
				
			}
		}
		
		//System.out.println(x);
		Sentence sen_3=sens.get(x+1);
		//System.out.println(sen_3.number);
		Sentence sen_4=sens.get(r);
		//System.out.println(sen_4.number);
		sens.remove(x+1);
		sens.add(x+1,sen_4);
		
		sens.remove(r);				
		sens.add(r,sen_3);
		//for(int o=0;o<sens.size();o++){
        //	System.out.println(sens.get(o).number);
        //}
		
		
		return x+1;
	}
	
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Sentence sen0,sen1,sen2,sen3;
        sen0=new Sentence();
        sen1=new Sentence();
        sen2=new Sentence();
        sen3=new Sentence();
        
        sen0.number=0;
        sen1.number=1;
        sen2.number=2;
        sen3.number=3;
        
        sen0.score=-0.534;
        
        sen1.score=0.334;
        
        sen2.score=0.14;
        
        sen3.score=-0.134;
        
        ArrayList<Sentence> list=new ArrayList<Sentence>(0);
        list.add(sen0);
        list.add(sen1);
        list.add(sen2);
        list.add(sen3);
        
        
        sens=list;
        sortByScore(0,list.size()-1);
        
        for(int i=0;i<sens.size();i++){
        	System.out.println(sens.get(i).number);
        }
        
	}

}
